# Vulnerability Research Methodology — Checklist v4.1 (Binary-only, PoC-first)

> **Scope** : méthodologie de recherche de vulnérabilités en contexte **autorisé** (audit interne, bug bounty, recherche responsable).  
> **Objectif** : transformer une analyse **ASM/microcode/pseudocode** en **PoC crash reproductible**, avec *gates*, *rollback* et artefacts traçables.

---

## 0) Principes de pilotage (anti-rabbit-hole)

### P0 — Identifiants & traçabilité (obligatoire)
- **Chaque bug** : `VULN-YYYY-NNN` (ex. `VULN-2026-001`)
- **Chaque binaire** : `TARGET-<name>-<buildid/hash>`
- **Chaque preuve** : référencée (fichier + outil + timestamp).

### P1 — Artefacts minimum (sinon FAIL)
Pour marquer une étape **PASS**, tu produis au minimum :
- 1 note `.md` structurée
- 1 preuve “dure” (ASM/pseudo/microcode/screenshot/log/commande+output)
- un lien explicite vers `VULN_ID` + `TARGET_ID`.

### P2 — Gates (stop criteria)
Si un **gate critique** échoue, tu **rollback** à l’étape indiquée. Pas de fuite en avant.

### P3 — Timeboxing (recommandé)
> Règle : si tu dépasses **2× le budget**, tu **réévalues** (score, reachability, pivot).
| Bloc | Budget indicatif |
|------|------------------|
| Baseline (Phase 0) | 30–90 min |
| Static/Triage (Phase A) | 1–4h / fonction |
| Validation (Phase B) | 2–6h / bug |
| Reachability (Phase C) | 1–4h |
| PoC crash (Phase E) | 2–8h |
| Patch diff (10.2) | 1–3h |

---

## 1) Notation standard (pour annoter vite et uniformément)

### N1 — Tags inline (dans tes notes)
- `[SINK:OOBW]`, `[SINK:OOBR]`, `[SINK:UAF]`, `[SINK:TYPECONF]`, `[SINK:RACE]`, `[SINK:LOGIC]`
- `[SRC:FILE:<fmt>:<offset/field>]`, `[SRC:IPC]`, `[SRC:NET]`, `[SRC:STATE]`
- `[CAST:U64→U32]`, `[CAST:SXTW]`, `[CAST:UXTW]`, `[MASK:&0x..]`, `[CLAMP]`
- `[CHECK:<cond>]` (et noter “bloquant”, “bypassable”, “inconnu”)
- `[GATE]` pour marquer les points Go/No-Go

### N2 — Définition “contrôlabilité PARTIELLE”
Quand tu écris **PARTIEL**, précise **quoi** :
- “contrôle **16 bits** sur un **u32**”, ou “contrôle amplitude (min/max)”, ou “contrôle via table (valeurs discrètes)”
- ce qui est **non contrôlé** (ex. bits hauts forcés, clamp, mapping, lookup)

---

## 2) Layout repo recommandé

```
/targets/<TARGET_ID>/
  metadata.md
  binaries/
  notes/

/bugs/<VULN_ID>/
  00_summary.md
  01_static.md
  02_validation.md
  03_reachability.md
  04_env.md
  05_poc.md
  evidence/
    asm_snippets.txt
    screenshots/
    logs/
  inputs/
    A_reach.bin
    B_trigger.bin
    C_crash.bin
triage.csv
triage_ranked.md
```

---

## PHASE 0 — BASELINE (process-level)

> **But** : prouver que le **pipeline global** est bon (push → trigger decode → logs), *sans* se soucier encore de la fonction vuln.

### Étape 0 : Baseline cible & “golden path”
**TODO**
- [ ] Identifier : process cible, lib, version OS/patch, modèle device
- [ ] Extraire : hash + build-id + dépendances critiques (libs chargées)
- [ ] “Golden run” : input valide connu → decode OK
- [ ] Script de repro minimal (push + trigger + collecte logs)

**RESULT**
```
☐ PASS | ☐ FAIL
TARGET_ID : ____________________________
Build-id / Hash : ______________________
Device/OS : ____________________________
Process réel de décodage : _____________
Artefacts :
- targets/<TARGET_ID>/metadata.md
- targets/<TARGET_ID>/notes/repro_script.md
Gate : si le process réel n’est pas identifié → STOP
```

> Clarif : **Phase 0 = process-level**.  
> La preuve “fonction atteinte” = Phase C / Étape 11.5 (function-level).

---

## PHASE A — STATIC + TRIAGE

### Étape 1 : Analyse fonction par fonction (statique)
**TODO**
- [ ] Annoter :
  - [ ] arithmétique tailles/indices (mul/add/shift/casts) + tags `[CAST]`
  - [ ] allocations (malloc/new/realloc/arena)
  - [ ] accès mémoire (read/write) + indexation
  - [ ] copies (memcpy/memmove/loops)
  - [ ] checks + early exits `[CHECK]`
- [ ] Marquer explicitement les **SINKS** `[SINK:*]`

**RESULT**
```
☐ PASS | ☐ FAIL
Fonction : _____________________________
RVA/VA : 0x_____________________________
Sinks : _________________________________
Patterns suspects : ______________________
Artefacts :
- bugs/<VULN_ID>/01_static.md (ou notes pré-triage)
- bugs/<VULN_ID>/evidence/asm_snippets.txt
```

---

### Étape 2 : Fiches “bug potentiel”
**TODO**
- [ ] Par bug :
  - type, variables, types hypothétiques
  - `[SRC:*]` hypothétique
  - `[SINK:*]` précis
  - reachability hypothétique (caller/entry point supposé)

**RESULT**
```
☐ PASS | ☐ FAIL
Bugs identifiés : ______
Format minimal :
{ id, fonction, addr, sink, type, source_hyp, confiance, notes }
Artefacts :
- triage.csv
- bugs/<VULN_ID>/00_summary.md (si retenu)
```

---

### Étape 3 : Priorisation (score PoC-first)
**TODO**
- [ ] Scorer (0–5) :
  - C = Confiance statique
  - I = Impact potentiel
  - R = Reachability estimée
  - K = Complexité (plus haut = plus dur)
- [ ] **Filtre** (recommandé) : si `R == 0` → **skip** (sauf justification)
- [ ] Score recommandé (PoC-first) :
  - `S = C + 2*I + 3*R - K`
- [ ] Top 3–5

**RESULT**
```
☐ PASS | ☐ FAIL
Top bugs : _____________________________
Bug sélectionné : ______________________
Justification : ________________________
Artefacts :
- triage_ranked.md
Gate : si R ≤ 1 → ne choisir que si raison forte (documenter)
```

---

### Étape 3.5 : Quick Reach Sanity (5–15 min max) ✅
> **But** : éviter 2h de validation sur du code “mort”.

**TODO**
- [ ] Hook/trace ultra simple sur la fonction candidate (Frida/tracepoints/DBI)
- [ ] Lancer **input valide** (golden) + 1–2 variations rapides
- [ ] Noter : “touché ? combien de fois ? args visibles ?”

**RESULT**
```
☐ PASS | ☐ FAIL
Fonction touchée : ☐ OUI | ☐ NON
Preuve : log minimal + timestamp
Action :
- si NON → fixer R=0, SKIP (retour Étape 3)
- si OUI → continuer Phase B
Artefacts :
- bugs/<VULN_ID>/evidence/logs/quick_reach.log
```

---

## PHASE B — VALIDATION TECHNIQUE (preuves statiques “dures”)

### Étape 4 : ASM vs pseudo (fidélité)
**TODO**
- [ ] Localiser instruction(s) fautive(s) (ASM)
- [ ] Vérifier W/X + extend (SXTW/UXTW) + truncations
- [ ] Confirmer ABI : arguments du sink (dest/src/len)

**RESULT**
```
☐ PASS | ☐ FAIL
Bug confirmé : ☐ OUI | ☐ DOUTE | ☐ NON
ASM proof : _____________________________
Types justifiés : ________________________
Artefacts :
- bugs/<VULN_ID>/02_validation.md (ASM proof)
Gate : si DOUTE persistante → retour Étape 1–2
```

---

### Étape 5 : Backward slicing (depuis le SINK)
**TODO**
- [ ] Remonter variables critiques (len/index/dest/base)
- [ ] Lister transformations `[CAST]/[MASK]/[CLAMP]`
- [ ] Identifier `[SRC:*]` la plus probable

**RESULT**
```
☐ PASS | ☐ FAIL
SINK : __________________ (func+addr)
Dataflow : SOURCE → … → SINK
Variables critiques : ____________________
Artefacts :
- bugs/<VULN_ID>/02_validation.md (Backward slice)
```

---

### Étape 6 : Taint (contrôlabilité)
**TODO**
- [ ] Décrire SOURCE (champ/offset/param/état)
- [ ] Contrôlabilité : OUI / NON / PARTIEL (avec définition concrète)
- [ ] Documenter transformations (casts, clamp, lookup)

**RESULT**
```
☐ PASS | ☐ FAIL
SOURCE : ________________________________
Contrôle : ☐ OUI | ☐ NON | ☐ PARTIEL (préciser)
Transformations : ________________________
Artefacts :
- bugs/<VULN_ID>/02_validation.md (Taint)
```

---

### Étape 7 : Control-flow & checks (exhaustif)
**TODO**
- [ ] Lister tous les checks `[CHECK]` entre SOURCE et SINK
- [ ] Classer : bloquant / potentiellement bypassable / inconnu
- [ ] Noter les early exits

**RESULT**
```
☐ PASS | ☐ FAIL
Nb checks : ______
Checks bloquants : ______
Contraintes nécessaires : ________________
Artefacts :
- bugs/<VULN_ID>/02_validation.md (Checks)
Gate : si bloquant systématique → retour Étape 3
```

---

### Étape 8 : Types & contraintes (calcul)
**TODO**
- [ ] Types exacts (ASM) : signed/unsigned, width
- [ ] Bornes + comportement limite (wrap/trunc)
- [ ] Calculer 1–3 triggers réalistes (et pourquoi parsing tient)

**RESULT**
```
☐ PASS | ☐ FAIL
Triggers : _______________________________
Calcul : _________________________________
Artefacts :
- bugs/<VULN_ID>/02_validation.md (Constraints)
```

---

### Étape 9 : Allocation vs accès (quantification)
**TODO**
- [ ] Calculer taille allouée (trigger)
- [ ] Calculer taille/index accédé (trigger)
- [ ] Quantifier l’écart

**RESULT**
```
☐ PASS | ☐ FAIL
Alloc : ______ bytes
Accès : ______ bytes / index ______
Dépassement : ______ bytes
Type : ☐ OOBR | ☐ OOBW | ☐ UAF | ☐ AUTRE
Artefacts :
- bugs/<VULN_ID>/02_validation.md (Alloc vs Access)
Gate : si dépassement = 0 → NO-GO → Étape 3
```

---

### Étape 10 : Verdict technique (GO/NO-GO)
**TODO**
- [ ] Résumer 4–9 (10 lignes max)
- [ ] Conditions exactes (triggers + checks + parsing)
- [ ] CWE + confiance

**RESULT**
```
☐ GO → Phase C
☐ NO-GO → Retour Étape 3
☐ PARTIEL → Documenter limites

Type : __________________  CWE : ________________
Conditions : _____________________________________
Artefacts :
- bugs/<VULN_ID>/02_validation.md (Verdict)
```

---

### Étape 10.1 : Root cause + pattern hunting
**TODO**
- [ ] Expliquer pourquoi le bug existe (catégorie)
- [ ] Chercher variantes (fonctions sœurs/helpers)

**RESULT**
```
☐ PASS | ☐ FAIL
Root cause : ____________________________
Variantes : ☐ OUI (____) | ☐ NON
Artefacts :
- bugs/<VULN_ID>/02_validation.md (Root cause)
```

---

### Étape 10.2 : Patch diffing (recommandé)
**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Patché : ☐ OUI | ☐ NON
Pattern de fix : ________________________
Versions affectées : _____________________
Artefacts :
- bugs/<VULN_ID>/02_validation.md (Patch diff)
```

---

## PHASE C — ATTEIGNABILITÉ (function-level) ✅

### Étape 11 : Call graph (statique)
**TODO**
- [ ] Remonter vers points d’entrée : exports/JNI/handlers/registries
- [ ] Documenter 1–2 chemins plausibles

**RESULT**
```
☐ PASS | ☐ FAIL
Entry points candidats : __________________
Chemin le plus court : ____________________
Artefacts :
- bugs/<VULN_ID>/03_reachability.md (Call graph)
```

---

### Étape 11.5 : Proof-of-Reach (dynamique minimale) — OBLIGATOIRE
**TODO**
- [ ] Instrumentation légère
- [ ] Confirmer : fonction atteinte avec input valide
- [ ] Logger args critiques (sizes/flags/champs)

**RESULT**
```
☐ PASS | ☐ FAIL
Fonction atteinte : ☐ OUI | ☐ NON
Trace : __________________________________
Artefacts :
- bugs/<VULN_ID>/evidence/logs/reach.log
Gate : si NON → retour Étape 11/13 (mauvais vecteur/chemin)
```

---

### Étape 12 : Conditions exactes du trigger (runtime)
**TODO**
- [ ] Format exact + headers/flags
- [ ] État (cache/metadata/thumbnail vs full)
- [ ] Bornes réalistes (dimensions/tailles)
- [ ] Construire un input minimal “reach” stable

**RESULT**
```
☐ PASS | ☐ FAIL
Conditions : _____________________________
Input minimal (reach) : ☐ OUI | ☐ NON
Artefacts :
- bugs/<VULN_ID>/03_reachability.md (Trigger conditions)
- bugs/<VULN_ID>/inputs/A_reach.bin
```

---

### Étape 13 : Mapping vecteurs (réaliste)
**TODO**
- [ ] Lister vecteurs (gallery/scanner/browser/mail/…)
- [ ] Pour chacun : permissions, interaction, contraintes
- [ ] Choisir le meilleur vecteur PoC

**RESULT**
```
☐ PASS | ☐ FAIL
Vecteurs viables : _______________________
Vecteur choisi : _________________________
Artefacts :
- bugs/<VULN_ID>/03_reachability.md (Entry mapping)
```

---

## PHASE D — ENVIRONNEMENT (ne doit pas bloquer le PoC)

### Étape 14 : Profil mitigations (checklist + hints)
**TODO**
- [ ] Lister : ASLR, CFI, PAC, MTE, SELinux, sandbox…
- [ ] Noter impact (haut niveau) sur exploitation

**Hints (rapides, variables selon Android/vendor)**
- MTE : vérifier propriétés/flags du build et du process (selon device : `getprop …memtag…`, flags de process, logs).  
  > Les champs exacts changent selon versions : documente **ce qui marche sur ta cible** (commande + output) dans `04_env.md`.

**RESULT**
```
☐ PASS | ☐ FAIL
Mitigations : ____________________________
Impact : _________________________________
Artefacts :
- bugs/<VULN_ID>/04_env.md
```

---

### Étape 15 : Format / mapping champs → variables
**TODO**
- [ ] Documenter structure du format
- [ ] Mapper champs → variables (celles du slicing)
- [ ] Règles “safe-to-mutate” (quels champs casseront le parsing)

**RESULT**
```
☐ PASS | ☐ FAIL
Template valide : ☐ OUI | ☐ NON
Mapping : __________________________________
Artefacts :
- bugs/<VULN_ID>/04_env.md (Format mapping)
- bugs/<VULN_ID>/inputs/A_reach.bin
```

---

### Étape 16 : Heap / allocateur (optionnel PoC)
**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Artefacts : bugs/<VULN_ID>/04_env.md (Heap)
```

### Étape 17 : Gadgets (hors scope PoC crash)
**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Artefacts : bugs/<VULN_ID>/04_env.md (Gadgets)
```

---

## PHASE E — PoC CRASH ✅

### Étape 18 : Inputs versionnés A/B/C
**TODO**
- [ ] A = reach (stable)
- [ ] B = reach + trigger partiel (force gros sizes/indices)
- [ ] C = crash (cible)
- [ ] S’assurer que parsing reste valide jusqu’au sink

**RESULT**
```
☐ PASS | ☐ FAIL
A_reach : _______________________________
B_trigger : _____________________________
C_crash : _______________________________
Artefacts :
- bugs/<VULN_ID>/inputs/A_reach.bin
- bugs/<VULN_ID>/inputs/B_trigger.bin
- bugs/<VULN_ID>/inputs/C_crash.bin
- bugs/<VULN_ID>/05_poc.md
```

---

### Étape 18.5 : Proof-of-SINK (recommandé) ✅
> **But** : distinguer “reach function” vs “exécute sink”.

**TODO**
- [ ] Ajouter un log/hook sur le sink (ou juste avant)
- [ ] Confirmer que le sink s’exécute avec les valeurs attendues (len/index)

**RESULT**
```
☐ PASS | ☐ FAIL
SINK exécuté : ☐ OUI | ☐ NON
Valeurs observées : ______________________
Artefacts :
- bugs/<VULN_ID>/evidence/logs/sink_reach.log
Gate : si NON → retour Étape 18/12 (input/conditions)
```

---

### Étape 19 : Test crash (env instrumenté si possible)
**TODO**
- [ ] Exécuter sur env instrumenté (sanitizers/trace)
- [ ] Capturer report + stack trace complet

**RESULT**
```
☐ PASS | ☐ FAIL
Crash : ☐ OUI | ☐ NON
Report : ________________________________
Stack trace : ____________________________
Artefacts :
- bugs/<VULN_ID>/evidence/logs/asan.txt (ou équivalent)
```

---

### Étape 19.1 : Diagnostic rollback (arbre de décision) ✅
Si `Crash = NON`, décider **où** rollback :

```
Crash = NON
├─ Proof-of-Reach (11.5) = NON → Étape 11/12/13 (mauvais chemin/vecteur)
├─ Proof-of-Reach = OUI, Proof-of-SINK (18.5) = NON → Étape 12 ou 18 (conditions/input)
├─ Proof-of-SINK = OUI, valeurs ≠ attendues → Étape 8 (contraintes/types faux)
└─ Proof-of-SINK = OUI, valeurs OK, pas de crash
   ├─ Overflows neutralisés (clamp/check caché) → Étape 7
   ├─ OOM/alloc fail/early exit silencieux → Étape 7/12
   └─ Différence build/device → Phase 0/10.2
```

---

### Étape 20 : Crash sur device réel (preuve “target-grade”)
**TODO**
- [ ] Trigger via vecteur choisi
- [ ] Capturer tombstone/logcat filtré

**RESULT**
```
☐ PASS | ☐ FAIL
Crash device : ☐ OUI | ☐ NON
Tombstone : ☐ OUI | ☐ NON
Artefacts :
- bugs/<VULN_ID>/evidence/logs/tombstone.txt
- bugs/<VULN_ID>/05_poc.md
```

---

### Étape 20.5 : Fuzzing confirmation (souvent recommandé)
> Utile pour trouver variantes & stabiliser rapidement le trigger.

**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Fuzzer : ________________________________
Crashes uniques : ______
Artefacts :
- bugs/<VULN_ID>/evidence/logs/fuzz_summary.md
```

---

### Étape 21–23 : Crash analysis & primitive (PoC-focused)
**Étape 21 (debug setup)** : ☐ PASS/FAIL/SKIP → `debug_setup.md`  
**Étape 22 (crash analysis)** : PC/regs/heap/stack → `05_poc.md`  
**Étape 23 (primitive assessment)** : type/taille/précision → `05_poc.md`

---

## PHASES F–J (optionnelles selon objectif)
> Conserver **haut niveau** si ton but immédiat est le crash/rapport.

- Phase F : primitive & stratégie (haut niveau)
- Phase G : exploit dev (haut niveau, si autorisé et nécessaire)
- Phase H : intégration & test
- Phase I : stabilisation
- Phase J : documentation/disclosure

---

## Annexes

### A1 — Colonnes recommandées pour `triage.csv`
```
vuln_id,target_id,function,addr,sink,source_hyp,type,cwe,C,I,R,K,score,status,notes
```

### A2 — Template de fiche bug (`bugs/<VULN_ID>/00_summary.md`)
```
# <VULN_ID> — <Titre court>

## Target
- TARGET_ID:
- Build-id / Hash:
- Device/OS:
- Process:

## Résumé
- Type:
- CWE:
- Impact:
- Confiance:

## SINK
- Fonction + addr:
- Instruction(s) clés:

## SOURCE
- Origine:
- Offset/champ:
- Contrôle: OUI/NON/PARTIEL (détails)

## Checks
- Liste des checks + conditions:

## Triggers
- Valeurs:
- Calcul:
- Validité parsing: pourquoi ça passe jusque sink

## Reachability
- Entry point:
- Proof-of-Reach (log):
- Proof-of-SINK (log):

## PoC
- A_reach:
- B_trigger:
- C_crash:
- Commandes de repro:
- Logs/tombstone:
```

# Vulnerability Research Methodology — Checklist v4.3 (Binary-only, PoC-first, “Reality-proof++”)

> **Scope** : usage **autorisé** (audit interne, bug bounty, recherche responsable).  
> **Objectif** : passer de l’ASM/microcode/pseudocode à un **PoC démontrable** (pas seulement “crash”), malgré les pièges réels : parsing fragile, état caché, ASAN≠prod, contraintes composées, instrumentation perturbatrice, non‑déterminisme.

---

## 0) Principes de pilotage

### P0 — Identifiants & traçabilité (obligatoire)
- **Bug** : `VULN-YYYY-NNN` (ex. `VULN-2026-001`)
- **Binaire** : `TARGET-<name>-<buildid/hash>`
- **Preuve** : référencée (fichier + outil + timestamp).

### P1 — Artefacts minimum (sinon FAIL)
Pour marquer une étape **PASS**, produire au minimum :
- 1 note `.md` structurée
- 1 preuve “dure” (ASM/pseudo/microcode/screenshot/log/commande+output)
- un lien explicite vers `VULN_ID` + `TARGET_ID`.

### P2 — Gates (stop criteria)
Si un **gate critique** échoue, **rollback** à l’étape indiquée.

### P3 — Timeboxing (recommandé)
> Règle : si tu dépasses **2× le budget**, tu **réévalues** (score, reachability, pivot).
| Bloc | Budget indicatif |
|------|------------------|
| Baseline (Phase 0) | 30–90 min |
| Static/Triage (Phase A) | 1–4h / fonction |
| Validation (Phase B) | 2–6h / bug |
| Reachability (Phase C) | 1–4h |
| PoC (Phase E) | 2–10h |
| Patch diff (10.2) | 1–3h |

---

## 1) Notation standard (annotations rapides)

### N1 — Tags inline
- `[SINK:OOBW]`, `[SINK:OOBR]`, `[SINK:UAF]`, `[SINK:TYPECONF]`, `[SINK:RACE]`, `[SINK:LOGIC]`
- `[SRC:FILE:<fmt>:<field/offset>]`, `[SRC:IPC]`, `[SRC:NET]`, `[SRC:STATE]`
- `[CAST:U64→U32]`, `[CAST:SXTW]`, `[CAST:UXTW]`, `[MASK:&0x..]`, `[CLAMP]`, `[LOOKUP]`
- `[CHECK:<cond>]` + statut : `BLOCKING / MAYBE / UNKNOWN`
- `[GATE]` pour les points Go/No-Go

### N2 — Contrôlabilité “PARTIEL”
Toujours préciser **quoi** :
- contrôlé : bits / plage / valeurs discrètes
- non contrôlé : clamp/lookup/bits forcés.

---

## 2) Définition des niveaux de PoC (IMPORTANT)

> Ça évite le piège “pas de crash ⇒ pas de PoC”.

- **PoC‑A (Reach)** : preuve que la **fonction** et le **sink** sont atteints + valeurs critiques observées.
- **PoC‑B (Corruption)** : preuve de **corruption/invariant cassé** (même sans crash).
- **PoC‑C (Crash)** : crash reproductible (prod‑like idéalement) + preuve sink + conditions.

**Règle** : si tu n’obtiens pas PoC‑C, vise PoC‑B (souvent suffisant pour un rapport solide).

---

## 3) Layout repo recommandé

```
/targets/<TARGET_ID>/
  metadata.md
  binaries/
  notes/

/bugs/<VULN_ID>/
  00_summary.md
  01_static.md
  02_validation.md
  03_reachability.md
  04_format_parsing.md
  04_env.md
  05_poc.md
  evidence/
    asm_snippets.txt
    screenshots/
    logs/
  inputs/
    A_reach.bin
    B_trigger.bin
    C_crash.bin
triage.csv
triage_ranked.md
```

---

# PHASE 0 — BASELINE (process-level)

## Étape 0 : Baseline + hash parity (obligatoire)
**TODO**
- [ ] Identifier : process cible, lib, version OS/patch, modèle device
- [ ] Extraire : hash + build-id + dépendances critiques
- [ ] **Hash parity** : binaire analysé == binaire sur device
- [ ] “Golden run” : input valide connu → decode OK
- [ ] Script repro minimal (push + trigger + collecte logs)

**RESULT**
```
☐ PASS | ☐ FAIL
TARGET_ID : ____________________________
Build-id/Hash (analysé) : ______________
Hash (device) : ________________________
Hash parity : ☐ OUI | ☐ NON
Process réel de décodage : _____________
Artefacts :
- targets/<TARGET_ID>/metadata.md
- targets/<TARGET_ID>/notes/repro_script.md
Gate : si Hash parity = NON → re-extraire / corriger TARGET_ID
```

---

# PHASE A — STATIC + TRIAGE

## Étape 1 : Analyse fonction par fonction
**TODO**
- [ ] Annoter arithmétique tailles/indices + `[CAST]`
- [ ] Allocations
- [ ] Accès mémoire + index
- [ ] Copies
- [ ] Checks + early exits `[CHECK]`
- [ ] Marquer sinks `[SINK:*]`

**RESULT**
```
☐ PASS | ☐ FAIL
Fonction : _____________________________
RVA/VA : 0x_____________________________
Sinks : _________________________________
Artefacts :
- bugs/<VULN_ID>/01_static.md
- bugs/<VULN_ID>/evidence/asm_snippets.txt
```

## Étape 2 : Fiches “bug potentiel”
**TODO**
- [ ] Type + variables + types hypothétiques
- [ ] `[SRC:*]` hypothétique
- [ ] `[SINK:*]` précis
- [ ] Reachability hypothétique (entry points)

**RESULT**
```
☐ PASS | ☐ FAIL
Bugs identifiés : ______
Artefacts : triage.csv
```

## Étape 3 : Priorisation PoC-first (R domine)
**TODO**
- [ ] Scorer (0–5) : C (confiance), I (impact), R (reach), K (complexité)
- [ ] Filtre : `if R == 0: skip` (sauf justification)
- [ ] Score : `S = C + 2*I + 3*R - K`
- [ ] Top 3–5

**RESULT**
```
☐ PASS | ☐ FAIL
Top bugs : _____________________________
Bug sélectionné : ______________________
Artefacts : triage_ranked.md
```

## Étape 3.5 : Quick Reach Sanity (5–15 min max) ✅
> But : éviter la validation lourde sur du code mort.

**TODO**
- [ ] Hook/trace minimal sur la fonction candidate
- [ ] Lancer golden + 1–2 variations rapides
- [ ] **Hit‑rate** : touches / N runs (ex. 8/10)

**Anti-debug / side-effects**
- [ ] Anti-debug/anti-hook suspecté : ☐ OUI | ☐ NON | ☐ INCONNU
- [ ] Si race suspectée : noter que l’instrumentation peut “guérir” la race

**RESULT**
```
☐ PASS | ☐ FAIL
Touché : ☐ OUI | ☐ NON
Hit-rate : ___ / ___
Action :
- si NON → R=0, SKIP (retour Étape 3)
- si OUI → Phase B
Artefacts : evidence/logs/quick_reach.log
```

---

# PHASE B — VALIDATION TECHNIQUE (preuves statiques)

## Étape 4 : ASM vs pseudo (fidélité)
**TODO**
- [ ] Instruction(s) fautive(s)
- [ ] W/X + extends (SXTW/UXTW) + truncations
- [ ] ABI : args du sink

**RESULT**
```
☐ PASS | ☐ FAIL
Bug confirmé : ☐ OUI | ☐ DOUTE | ☐ NON
Artefacts : 02_validation.md (ASM proof)
```

## Étape 5 : Backward slicing (depuis le SINK)
**TODO**
- [ ] Remonter len/index/dest/base
- [ ] Lister transformations `[CAST]/[MASK]/[CLAMP]/[LOOKUP]`
- [ ] Identifier `[SRC:*]`

**RESULT**
```
☐ PASS | ☐ FAIL
Dataflow : SOURCE → … → SINK
Artefacts : 02_validation.md (Backward slice)
```

## Étape 6 : Taint (contrôlabilité)
**RESULT**
```
☐ PASS | ☐ FAIL
SOURCE : ________________________________
Contrôle : ☐ OUI | ☐ NON | ☐ PARTIEL (détails)
Artefacts : 02_validation.md (Taint)
```

## Étape 7 : Checks (liste exhaustive)
**RESULT**
```
☐ PASS | ☐ FAIL
Checks bloquants : ______
Artefacts : 02_validation.md (Checks)
```

## Étape 8 : Contraintes & triggers (avec dépendances)
**TODO**
- [ ] Types exacts (ASM) + limites (wrap/trunc)
- [ ] Calculer 1–3 triggers réalistes
- [ ] Nb contraintes interdépendantes : ______
- [ ] Si > 3 → Z3/solver : ☐ OUI | ☐ SKIP (justifier)

**RESULT**
```
☐ PASS | ☐ FAIL
Triggers : _______________________________
Nb contraintes : ______  Solver : ☐ OUI | ☐ NON
Artefacts : 02_validation.md (Constraints)
```

## Étape 9 : Allocation vs accès + attente de crash
**TODO**
- [ ] Quantifier dépassement
- [ ] Estimer la “crashabilité” :
  - cible après buffer : ☐ metadata | ☐ autre objet | ☐ padding | ☐ unmapped | ☐ inconnu
  - crash attendu : ☐ immédiat | ☐ différé | ☐ corruption silencieuse

**RESULT**
```
☐ PASS | ☐ FAIL
Dépassement : ______ bytes
Crash attendu : __________________________
Artefacts : 02_validation.md (Alloc vs Access)
```

## Étape 10 : Verdict technique (GO/NO‑GO)
**RESULT**
```
☐ GO → Phase C
☐ NO-GO → Retour Étape 3
☐ PARTIEL → Documenter limites
Artefacts : 02_validation.md (Verdict)
```

## Étape 10.2 : Patch diffing (recommandé)
**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Patché : ☐ OUI | ☐ NON
Artefacts : 02_validation.md (Patch diff)
```

---

# PHASE C — ATTEIGNABILITÉ (function-level)

## Étape 11 : Call graph (statique) + VM/JIT
**TODO**
- [ ] Remonter vers entry points (exports/JNI/handlers)
- [ ] VM/JIT suspecté : ☐ OUI | ☐ NON | ☐ INCONNU (si OUI → privilégier traces runtime)

**RESULT**
```
☐ PASS | ☐ FAIL
Artefacts : 03_reachability.md (Call graph)
```

## Étape 11.5 : Proof‑of‑Reach (OBLIGATOIRE)
**TODO**
- [ ] Confirmer fonction atteinte avec input valide
- [ ] Logger args critiques
- [ ] **Hit‑rate** : ___ / ___ (ex. 17/20)

**Instrumentation risks**
- [ ] Anti-debug/anti-hook : ☐ OUI | ☐ NON | ☐ INCONNU
- [ ] Side-effects (timing/layout/CFI) : documenter si pertinent

**RESULT**
```
☐ PASS | ☐ FAIL
Fonction atteinte : ☐ OUI | ☐ NON
Hit-rate : ___ / ___
Artefacts : evidence/logs/reach.log
Gate : si NON → Étape 11/12/13
```

## Étape 12 : Trigger conditions + hidden state
**TODO**
- [ ] Conditions runtime (thumbnail/full, cache, metadata, limites)
- [ ] Hidden state :
  - [ ] globals/statiques lues
  - [ ] modes/flags dérivés d’autres champs
  - [ ] dépendances d’ordre d’appels (init, warmup)
  - [ ] dépendances externes (MediaStore/DB/scan)
- [ ] Construire A_reach stable

**RESULT**
```
☐ PASS | ☐ FAIL
A_reach : ☐ OUI | ☐ NON
Artefacts :
- 03_reachability.md (Trigger + hidden state)
- inputs/A_reach.bin
```

## Étape 13 : Mapping vecteurs (réaliste)
**RESULT**
```
☐ PASS | ☐ FAIL
Vecteur choisi : _________________________
Artefacts : 03_reachability.md (Entry mapping)
```

---

# PHASE D — FORMAT & PARSING SURVIVAL (anti “OOM early exit”)

## Étape 15 : Format mapping + endianness/alignment
**TODO**
- [ ] Ordre de parsing + dépendances
- [ ] Endianness : ☐ LE | ☐ BE | ☐ mixed
- [ ] Alignment requirements : __________________
- [ ] Champs “kill-switch” (OOM/early exit/checks)

**RESULT**
```
☐ PASS | ☐ FAIL
Artefacts : 04_format_parsing.md (Format mapping)
```

## Étape 15.5 : Parsing Survival Window (fenêtre de valeurs) ✅
**TODO**
- [ ] Champs lus **avant sink** dépendant du trigger
- [ ] Pré-checks/allocations/tables init déclenchés
- [ ] Fenêtre : `trigger_min..trigger_max` où parsing survit ET bug triggeable

**RESULT**
```
☐ PASS | ☐ FAIL
Fenêtre survie : _________________________
Champs bloquants : _______________________
Artefacts : 04_format_parsing.md (Survival window)
```

## Étape 15.6 : Survival Search Loop (procédure de convergence) ✅
> Transformer 15.5 en “algo” reproductible.

**TODO**
- [ ] Définir un paramètre “intensité trigger” `t` (ex. width/height/len)
- [ ] **Rampe progressive** : augmenter `t` par paliers (10–20% ou +Δ)
- [ ] À chaque palier, logguer le dernier checkpoint atteint (reach/sink/check)
- [ ] Si parsing casse :
  - [ ] faire une **bisection** entre dernier OK et premier FAIL
  - [ ] isoler la condition bloquante (check/alloc/limit)
- [ ] Résultat : une valeur “max survivable” + une valeur “min triggeable”

**RESULT**
```
☐ PASS | ☐ FAIL
t_min_trig : ______  t_max_survive : ______
Delta exploitable : ______
Artefacts :
- evidence/logs/survival_loop.log
- 04_format_parsing.md (Search loop)
```

---

# PHASE ENV (optionnelle) — Mitigations / Heap (utile pour expliquer divergences)

## Étape 14 : Mitigations (haut niveau)
**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Mitigations : ____________________________
Artefacts : 04_env.md
```

## Étape 16 : Heap/allocateur (optionnel PoC, utile si ASAN≠prod)
**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Allocateur : _____________________________
Artefacts : 04_env.md (Heap)
```

---

# PHASE E — PoC (A/B/C)

## Étape 18 : Inputs A/B/C
**TODO**
- [ ] A = reach stable
- [ ] B = trigger partiel (survit parsing)
- [ ] C = crash (si possible)

**RESULT**
```
☐ PASS | ☐ FAIL
A_reach : _______________________________
B_trigger : _____________________________
C_crash : _______________________________
Artefacts : inputs/A_reach.bin, B_trigger.bin, C_crash.bin
```

## Étape 18.5 : Proof‑of‑SINK (recommandé)
**TODO**
- [ ] Hook/log avant sink (ou sur memcpy/store)
- [ ] Valeurs observées (len/index/dest) + cohérence avec calculs
- [ ] **Hit‑rate** : ___ / ___

**RESULT**
```
☐ PASS | ☐ FAIL
SINK exécuté : ☐ OUI | ☐ NON
Hit-rate : ___ / ___
Valeurs : ________________________________
Artefacts : evidence/logs/sink_reach.log
```

## Étape 18.7 : Proof‑of‑Corruption (PoC‑B) ✅
> À utiliser quand sink=OUI mais pas de crash.

**TODO**
- [ ] Définir un **invariant** post‑sink (structure cohérente, taille attendue, checksum, compteur, “magic”, etc.)
- [ ] Capturer “before/after” minimal autour de l’objet/état affecté
- [ ] Démontrer une divergence déterministe (ou taux de repro)

**RESULT**
```
☐ PASS | ☐ FAIL
Corruption prouvée : ☐ OUI | ☐ NON
Invariant cassé : ________________________
Repro : ___ / ___
Artefacts :
- evidence/logs/corruption_proof.log
- 05_poc.md (Corruption proof)
[GATE] Si OUI → PoC‑B atteint (même sans crash)
```

## Étape 19 : Crash validation — ASAN vs prod (gate assoupli, plus réaliste)
**TODO**
- [ ] Run sanitizer (si possible)
- [ ] Run prod‑like (sans sanitizer)
- [ ] Comparer : path, heap layout, checks, early exits

**Règles de PASS**
- PASS si **prod‑like crash = OUI**  → PoC‑C
- PASS si **ASAN crash = OUI** + **Proof‑of‑SINK = OUI** + (au moins un) :
  - [ ] Proof‑of‑Corruption = OUI (PoC‑B), ou
  - [ ] explication argumentée “pourquoi prod ne crashe pas” (layout/padding/quarantine) + trace/proof
- FAIL si ASAN crash sans proof‑of‑sink (retour 18.5)

**RESULT**
```
☐ PASS | ☐ FAIL
Crash sanitizer : ☐ OUI | ☐ NON | ☐ N/A
Crash prod-like : ☐ OUI | ☐ NON
PoC atteint : ☐ A | ☐ B | ☐ C
Artefacts :
- evidence/logs/asan.txt (si applicable)
- evidence/logs/prod_run.txt
- 05_poc.md (ASAN vs prod)
```

## Étape 19.1 : Diagnostic rollback (arbre)
Si `Crash = NON` :

```
Crash = NON
├─ Reach (11.5) = NON → Étape 11/12/13
├─ Reach = OUI, SINK (18.5) = NON → Étape 12 (hidden state) ou 18 (input) ou 15.6
├─ SINK = OUI, valeurs ≠ attendues → Étape 8 (contraintes/types/endianness)
└─ SINK = OUI, valeurs OK, pas de crash
   ├─ viser Proof-of-Corruption (18.7) → PoC-B
   ├─ corruption silencieuse/padding → Étape 9 + 16 (heap)
   ├─ clamp/check tardif → Étape 7 + 15.5/15.6
   └─ build/device différent → Étape 0 + 10.2
```

## Étape 20 : Crash sur device réel
**RESULT**
```
☐ PASS | ☐ FAIL
Crash device : ☐ OUI | ☐ NON
Tombstone : ☐ OUI | ☐ NON
Artefacts : evidence/logs/tombstone.txt
```

## Étape 20.5 : Fuzzing confirmation (souvent recommandé)
**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Fuzzer : ________________________________
Crashes uniques : ______
Artefacts : evidence/logs/fuzz_summary.md
```

---

## Annexes

### A1 — Colonnes recommandées `triage.csv`
```
vuln_id,target_id,function,addr,sink,source_hyp,type,cwe,C,I,R,K,score,status,notes
```

### A2 — Template `bugs/<VULN_ID>/00_summary.md`
```
# <VULN_ID> — <Titre court>

## Target
- TARGET_ID:
- Hash (analysé):
- Hash (device):
- Hash parity:
- Device/OS:
- Process:

## Résumé
- Type / CWE:
- Impact:
- Confiance:

## Reach / Sink / Corruption
- Proof-of-Reach (hit-rate):
- Proof-of-SINK (hit-rate):
- Proof-of-Corruption (hit-rate):
- PoC atteint : A / B / C

## Triggers / Parsing survival
- Triggers:
- Fenêtre survie (min..max):
- Search loop (15.6) résultats:
- Endianness/alignment:

## Checks / Hidden state
- Checks:
- Hidden state:

## PoC artefacts
- A_reach:
- B_trigger:
- C_crash:
- ASAN vs prod:
- Logs/tombstone:
```

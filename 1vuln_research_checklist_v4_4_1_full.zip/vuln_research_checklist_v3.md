# Vulnerability Research Methodology - Checklist v3

---

## PHASE A : ANALYSE STATIQUE DU CODE

---

### Étape 1 : Analyse Fonction par Fonction

**TODO:**
- [ ] Pour chaque fonction, analyser le pseudocode :
  - [ ] Identifier les opérations arithmétiques sur tailles/indices
  - [ ] Repérer les allocations mémoire
  - [ ] Repérer les accès mémoire (read/write)
  - [ ] Repérer les copies (memcpy, strcpy, loops)
  - [ ] Vérifier les validations de bornes
- [ ] Annoter le code avec les observations
- [ ] Documenter les patterns suspects

**RESULT:**
```
☐ PASS | ☐ FAIL
Fonction analysée : _______________
Patterns suspects trouvés : ___
Notes : _______________
```

---

### Étape 2 : Identification des Bugs Potentiels

**TODO:**
- [ ] Pour chaque pattern suspect, évaluer :
  - Type de bug potentiel (overflow, OOB, UAF, type confusion...)
  - Variables impliquées
  - Conditions de déclenchement
  - Contrôlabilité par l'attaquant (hypothèse)
- [ ] Créer une fiche par bug potentiel

**RESULT:**
```
☐ PASS | ☐ FAIL
Bugs potentiels identifiés : ___
Format : { id, fonction, ligne, type, description, confiance }
```

---

### Étape 3 : Priorisation des Bugs Potentiels

**TODO:**
- [ ] Scorer chaque bug potentiel :
  - Confiance (HIGH/MEDIUM/LOW)
  - Impact potentiel (crash, RCE, info leak)
  - Complexité d'atteinte estimée
- [ ] Classer par score
- [ ] Sélectionner le top 3-5 pour validation

**RESULT:**
```
☐ PASS | ☐ FAIL
Bugs classés : ___
Bug sélectionné pour validation : _______________
Fonction : _______________
Adresse : 0x_______________
```

---

## PHASE B : VALIDATION DU BUG

---

### Étape 4 : Analyse Approfondie du Bug Sélectionné

**TODO:**
- [ ] Relire le pseudocode en détail
- [ ] Comparer avec l'ASM (vérifier fidélité décompilation)
- [ ] Vérifier le microcode si doute
- [ ] Identifier précisément :
  - La variable vulnérable
  - L'opération problématique
  - Les types de données (int8, int32, size_t...)

**RESULT:**
```
☐ PASS | ☐ FAIL
Bug confirmé en statique : ☐ OUI | ☐ DOUTE | ☐ NON
Variable : _______________
Opération : _______________
Types : _______________
```

---

### Étape 5 : Backward Slicing (depuis le SINK)

**TODO:**
- [ ] Partir du SINK (point de vuln/corruption)
- [ ] Remonter chaque variable impliquée
- [ ] Tracer les dépendances de données
- [ ] Identifier la SOURCE (d'où vient la donnée ?)
- [ ] Documenter le chemin complet

**RESULT:**
```
☐ PASS | ☐ FAIL
SINK : fonction ___, ligne ___
SOURCE identifiée : ☐ OUI | ☐ NON
Chemin : SOURCE → ... → SINK
Variables critiques : _______________
Nombre de fonctions traversées : ___
```

---

### Étape 6 : Taint Analysis

**TODO:**
- [ ] Identifier la nature de la SOURCE :
  - [ ] Input fichier (quel champ ?)
  - [ ] Input réseau
  - [ ] IPC / Binder
  - [ ] Autre : ___
- [ ] Vérifier : donnée contrôlable par attaquant ?
- [ ] Documenter les transformations subies (masks, shifts, casts)

**RESULT:**
```
☐ PASS | ☐ FAIL
SOURCE contrôlable : ☐ OUI | ☐ NON | ☐ PARTIEL
Type d'input : _______________
Champ/offset dans l'input : _______________
Transformations : _______________
```

---

### Étape 7 : Control Flow Analysis

**TODO:**
- [ ] Lister tous les CHECKS entre SOURCE et SINK
- [ ] Pour chaque check :
  - Condition exacte
  - Bypassable ? Comment ?
- [ ] Identifier les contraintes à satisfaire
- [ ] Vérifier les early exits

**RESULT:**
```
☐ PASS | ☐ FAIL
Nombre de checks : ___
Checks bypassables : ___
Contraintes pour atteindre SINK : _______________
Chemin viable : ☐ OUI | ☐ NON
```

---

### Étape 8 : Type Analysis + Calcul des Contraintes

**TODO:**
- [ ] Pour chaque variable du chemin :
  - Type exact (signé/non signé, taille)
  - Valeurs min/max possibles
  - Comportement aux limites (wrap, truncation)
- [ ] Calculer les valeurs qui triggent le bug
- [ ] Utiliser Z3/solver si contraintes complexes

**RESULT:**
```
☐ PASS | ☐ FAIL
Overflow/underflow possible : ☐ OUI | ☐ NON
Valeur(s) trigger : _______________
Calcul : _______________ → résultat problématique ___
```

---

### Étape 9 : Comparaison Allocation vs Accès

**TODO:**
- [ ] Calculer la taille allouée (avec valeurs trigger)
- [ ] Calculer la taille/index accédé (avec mêmes valeurs)
- [ ] Comparer : accès hors bornes ?
- [ ] Quantifier le dépassement

**RESULT:**
```
☐ PASS | ☐ FAIL
Taille allouée : ___ bytes
Taille/index accédé : ___
Dépassement : ___ bytes (OOB) | 0 (pas de bug)
Type : ☐ OOB READ | ☐ OOB WRITE | ☐ UNDERFLOW | ☐ AUTRE
```

---

### Étape 10 : Verdict Technique sur le Bug

**TODO:**
- [ ] Synthétiser les résultats des étapes 4-9
- [ ] Conclure sur la validité technique
- [ ] Documenter les conditions exactes du trigger

**RESULT:**
```
☐ VALIDE → Continuer Phase C
☐ INVALIDE → Retour Étape 3 (bug suivant)
☐ PARTIEL → Documenter limitations, décider

Type de bug confirmé : _______________
CWE : _______________
Résumé : _______________
```

---

### Étape 10.5 : Root Cause Analysis

**TODO:**
- [ ] Identifier POURQUOI le bug existe
- [ ] Catégoriser : erreur logique, mauvaise API, integer issue, race...
- [ ] Vérifier si pattern répété ailleurs dans le code
- [ ] Chercher variantes dans fonctions similaires

**RESULT:**
```
☐ PASS | ☐ FAIL
Root cause : _______________
Catégorie : _______________
Bugs similaires potentiels : ☐ OUI (___) | ☐ NON
```

---

### Étape 10.7 : Patch Diffing (optionnel)

**TODO:**
- [ ] Récupérer version plus récente du binaire
- [ ] Diff avec BinDiff / Diaphora
- [ ] Vérifier si la fonction a été modifiée
- [ ] Analyser le pattern de fix si patché

**RESULT:**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Bug déjà patché : ☐ OUI → décider suite | ☐ NON → CONTINUE
Pattern de fix : _______________
Versions affectées : _______________
```

---

## PHASE C : ATTEIGNABILITÉ

---

### Étape 11 : Call Graph Analysis

**TODO:**
- [ ] Construire call graph depuis fonction vulnérable
- [ ] Remonter vers les points d'entrée (exports, handlers)
- [ ] Identifier tous les chemins possibles
- [ ] Documenter les callers à chaque niveau

**RESULT:**
```
☐ PASS | ☐ FAIL
Profondeur call graph : ___ niveaux
Points d'entrée identifiés : _______________
Chemin le plus court : _______________
```

---

### Étape 11.5 : Dynamic Validation

**TODO:**
- [ ] Instrumenter avec Frida / DynamoRIO
- [ ] Tracer les appels réels avec inputs légitimes
- [ ] Confirmer que le chemin statique est emprunté
- [ ] Identifier les conditions runtime

**RESULT:**
```
☐ PASS | ☐ FAIL
Chemin confirmé dynamiquement : ☐ OUI | ☐ NON
Trace : _______________
Divergences avec analyse statique : _______________
```

---

### Étape 12 : Trigger Path Validation

**TODO:**
- [ ] Identifier les conditions exactes pour atteindre la fonction :
  - Format de fichier / type de message
  - Headers/options/flags requis
  - État du process
  - Taille minimale/maximale
- [ ] Créer input minimal valide qui atteint la fonction

**RESULT:**
```
☐ PASS | ☐ FAIL
Conditions de trigger : _______________
Input minimal créé : ☐ OUI
Fonction atteinte confirmée : ☐ OUI | ☐ NON
```

---

### Étape 13 : Entry Point Mapping

**TODO:**
- [ ] Lister tous les vecteurs d'attaque possibles :
  - [ ] Gallery / Media Scanner
  - [ ] MMS / RCS
  - [ ] Browser
  - [ ] Email client
  - [ ] File Manager
  - [ ] Bluetooth / NFC
  - [ ] Autre : ___
- [ ] Pour chaque vecteur : permissions requises, interaction user

**RESULT:**
```
☐ PASS | ☐ FAIL
Vecteurs viables : _______________
Meilleur vecteur : _______________
0-click possible : ☐ OUI | ☐ NON
1-click requis : ☐ OUI | ☐ NON
```

---

## PHASE D : ANALYSE DE L'ENVIRONNEMENT

---

### Étape 14 : Mitigations Analysis

**TODO:**
- [ ] Identifier les mitigations actives sur le process cible :
  - [ ] ASLR (niveau)
  - [ ] Stack Canary
  - [ ] CFI (type)
  - [ ] PAC (ARM64)
  - [ ] MTE (ARM64)
  - [ ] Seccomp (filtres)
  - [ ] SELinux (contexte)
  - [ ] Sandbox (type)
- [ ] Documenter l'impact sur l'exploitation

**RESULT:**
```
☐ PASS | ☐ FAIL
Mitigations actives : _______________
Contraintes pour exploit : _______________
Bypass nécessaires : _______________
```

---

### Étape 15 : File Format / Protocol Analysis

**TODO:**
- [ ] Étudier la spécification du format (JPEG, PNG, MP4, proto...)
- [ ] Identifier la structure : headers, chunks, markers
- [ ] Comprendre le parsing par le code vulnérable
- [ ] Documenter les champs contrôlables
- [ ] Mapper les champs vers les variables du code

**RESULT:**
```
☐ PASS | ☐ FAIL
Format : _______________
Structure documentée : ☐ OUI
Champ trigger → variable code : _______________
Template de fichier valide créé : ☐ OUI
```

---

### Étape 16 : Heap/Memory Layout Analysis

**TODO:**
- [ ] Identifier l'allocateur utilisé (jemalloc, scudo, partitionalloc)
- [ ] Comprendre les size classes / buckets
- [ ] Analyser le layout mémoire typique du process
- [ ] Identifier les objets intéressants à proximité

**RESULT:**
```
☐ PASS | ☐ FAIL
Allocateur : _______________
Size class du buffer vulnérable : ___
Objets adjacents potentiels : _______________
Stratégie heap feng shui : _______________
```

---

### Étape 17 : Gadget Hunting

**TODO:**
- [ ] Lister les libraries chargées dans le process
- [ ] Scanner les gadgets avec ROPgadget / ropper
- [ ] Filtrer les gadgets compatibles CFI/PAC si applicable
- [ ] Identifier les gadgets utiles : pivot, write, call

**RESULT:**
```
☐ PASS | ☐ FAIL
Libraries analysées : _______________
Gadgets utiles trouvés : ___ 
Gadgets compatibles mitigations : ☐ OUI | ☐ NON
Liste : gadgets.txt
```

---

## PHASE E : POC CRASH

---

### Étape 18 : Craft du Fichier/Input Malicieux

**TODO:**
- [ ] Partir du template valide (Étape 15)
- [ ] Insérer les valeurs trigger calculées (Étape 8-9)
- [ ] S'assurer que l'input reste valide jusqu'au point vuln
- [ ] Générer le fichier/input malicieux

**RESULT:**
```
☐ PASS | ☐ FAIL
Input malicieux créé : _______________
Taille : ___ bytes
Valeurs trigger insérées à offset : _______________
```

---

### Étape 19 : Test Crash sur Émulateur

**TODO:**
- [ ] Configurer émulateur avec ASAN/MSAN
- [ ] Exécuter avec l'input malicieux
- [ ] Capturer le crash report
- [ ] Analyser le type de corruption

**RESULT:**
```
☐ PASS | ☐ FAIL
Émulateur : _______________
Crash reproduit : ☐ OUI | ☐ NON
Type ASAN : _______________
Stack trace : _______________
```

---

### Étape 20 : Test Crash sur Device Réel

**TODO:**
- [ ] Préparer device (rooté si possible pour debug)
- [ ] Transférer input malicieux
- [ ] Trigger via le vecteur choisi
- [ ] Capturer tombstone / crash log

**RESULT:**
```
☐ PASS | ☐ FAIL
Device : _______________
Android/OS version : _______________
Crash reproduit : ☐ OUI | ☐ NON
Tombstone capturé : ☐ OUI
```

---

### Étape 20.5 : Fuzzing Confirmation (optionnel)

**TODO:**
- [ ] Configurer harness pour AFL / libFuzzer
- [ ] Utiliser le fichier malicieux comme seed
- [ ] Fuzzer pour trouver variantes
- [ ] Collecter tous les crashes uniques

**RESULT:**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Fuzzer utilisé : _______________
Crashes trouvés : ___
Variantes intéressantes : _______________
```

---

### Étape 21 : Debug Environment Setup

**TODO:**
- [ ] Installer lldb-server / gdbserver sur device
- [ ] Configurer frida-server
- [ ] Setup adb logcat filtering
- [ ] Préparer symbols si disponibles
- [ ] Tester connexion debugger

**RESULT:**
```
☐ PASS | ☐ FAIL
Debugger fonctionnel : ☐ OUI | ☐ NON
Frida fonctionnel : ☐ OUI | ☐ NON
Symbols chargés : ☐ OUI | ☐ NON
```

---

### Étape 22 : Crash Analysis

**TODO:**
- [ ] Attacher debugger au moment du crash
- [ ] Dumper les registres
- [ ] Analyser l'état de la stack
- [ ] Analyser l'état du heap
- [ ] Identifier ce qui est contrôlé

**RESULT:**
```
☐ PASS | ☐ FAIL
PC/IP au crash : 0x_______________
Registres contrôlés : _______________
État stack : _______________
État heap : _______________
```

---

### Étape 23 : Primitive Assessment

**TODO:**
- [ ] Évaluer précisément le contrôle obtenu :
  - Quels registres ?
  - Quelle taille de corruption ?
  - Quelle précision (byte, word, arbitrary) ?
  - Quel timing (immédiat, différé) ?
- [ ] Classifier la primitive

**RESULT:**
```
☐ PASS | ☐ FAIL
Type de primitive : _______________
Taille contrôlée : ___ bytes
Précision : _______________
Registres contrôlés : _______________
Évaluation : ☐ FORTE | ☐ MOYENNE | ☐ FAIBLE
```

---

## PHASE F : PRIMITIVE ET STRATÉGIE

---

### Étape 24 : Primitive Construction

**TODO:**
- [ ] Définir formellement la primitive :
  - Type : OOB read/write, UAF, type confusion...
  - Taille : X bytes
  - Contrôle : quelles valeurs, où
  - Répétabilité : une fois, multiple
- [ ] Documenter les contraintes

**RESULT:**
```
☐ PASS | ☐ FAIL
Primitive formelle : _______________
Exemple : "OOB write de 64 bytes après buffer de 128 bytes"
Contraintes : _______________
```

---

### Étape 25 : Exploit Strategy Design

**TODO:**
- [ ] Définir la chaîne d'exploitation complète :
  1. Info leak (si ASLR)
  2. Primitive → corruption cible
  3. Control flow hijack
  4. Code execution
  5. Sandbox escape (si applicable)
- [ ] Identifier les dépendances entre étapes

**RESULT:**
```
☐ PASS | ☐ FAIL
Stratégie documentée : ☐ OUI
Nombre d'étapes : ___
Bugs supplémentaires requis : ☐ OUI (___)  | ☐ NON
```

---

### Étape 26 : Info Leak Development

**TODO:**
- [ ] Identifier la cible du leak : heap, stack, code base
- [ ] Construire le leak avec la primitive disponible
- [ ] Ou utiliser bug auxiliaire (voir 26.3)
- [ ] Tester et valider le leak

**RESULT:**
```
☐ PASS | ☐ FAIL | ☐ N/A (pas d'ASLR)
Type de leak : _______________
Adresse leakée : _______________
Fiabilité : ___%
```

---

### Étape 26.3 : Auxiliary Bug Search

**TODO:**
- [ ] Si leak impossible avec bug principal :
  - [ ] Chercher OOB read dans l'analyse initiale
  - [ ] Chercher format string
  - [ ] Chercher uninitialized memory
  - [ ] Chercher timing side-channel
- [ ] Valider le bug auxiliaire

**RESULT:**
```
☐ PASS | ☐ FAIL | ☐ N/A
Bug auxiliaire trouvé : ☐ OUI | ☐ NON
Type : _______________
Localisation : _______________
```

---

### Étape 26.5 : Target Identification

**TODO:**
- [ ] Identifier les cibles de corruption :
  - [ ] vtables
  - [ ] Function pointers
  - [ ] Return addresses
  - [ ] Allocator metadata
  - [ ] Critical flags / sizes
- [ ] Choisir la cible optimale selon mitigations

**RESULT:**
```
☐ PASS | ☐ FAIL
Cible choisie : _______________
Raison : _______________
Offset depuis buffer vulnérable : ___
```

---

### Étape 26.7 : Leak Integration / Multi-Stage Design

**TODO:**
- [ ] Déterminer : single-stage ou multi-stage ?
- [ ] Si multi-stage :
  - Stage 1 : leak
  - Stage 2 : exploit
  - Mécanisme de transition
- [ ] Documenter le flow complet

**RESULT:**
```
☐ PASS | ☐ FAIL
Type : ☐ SINGLE-STAGE | ☐ MULTI-STAGE
Nombre de triggers : ___
Flow documenté : ☐ OUI
```

---

## PHASE G : EXPLOIT DEVELOPMENT

---

### Étape 27 : Mitigation Bypass Strategy

**TODO:**
- [ ] Pour chaque mitigation active, définir le bypass :
  - [ ] ASLR : leak développé (Étape 26)
  - [ ] CFI : technique choisie ___
  - [ ] PAC : technique choisie ___
  - [ ] Stack canary : technique choisie ___
  - [ ] MTE : technique choisie ___
- [ ] Valider faisabilité de chaque bypass

**RESULT:**
```
☐ PASS | ☐ FAIL
Tous les bypass définis : ☐ OUI | ☐ NON
Bypass bloquant : _______________
```

---

### Étape 27.3 : Allocator-Specific Techniques

**TODO:**
- [ ] Adapter à l'allocateur identifié (Étape 16) :
  - jemalloc : size class manipulation
  - Scudo : quarantine bypass, chunk header
  - PartitionAlloc : bucket spray
  - tcmalloc : specific techniques
- [ ] Développer les primitives allocateur

**RESULT:**
```
☐ PASS | ☐ FAIL
Allocateur : _______________
Technique : _______________
PoC technique validé : ☐ OUI | ☐ NON
```

---

### Étape 27.5 : Heap Feng Shui / Memory Grooming

**TODO:**
- [ ] Définir le layout mémoire cible
- [ ] Identifier les allocations contrôlables
- [ ] Développer la séquence de spray
- [ ] Créer les trous (holes) nécessaires
- [ ] Tester le placement

**RESULT:**
```
☐ PASS | ☐ FAIL
Layout cible : _______________
Séquence de spray : _______________
Taux de succès placement : ___%
```

---

### Étape 28 : Control Flow Hijack

**TODO:**
- [ ] Implémenter la corruption de la cible (Étape 26.5)
- [ ] Écraser : pointer fonction / vtable / ret addr / GOT
- [ ] Valider le hijack : PC contrôlé ?
- [ ] Respecter les contraintes CFI/PAC

**RESULT:**
```
☐ PASS | ☐ FAIL
Cible corrompue : _______________
PC contrôlé : ☐ OUI | ☐ NON
Valeur PC : 0x_______________
```

---

### Étape 29 : ROP/JOP Chain Construction

**TODO:**
- [ ] Sélectionner les gadgets (Étape 17)
- [ ] Construire la chaîne :
  - Stack pivot si nécessaire
  - Setup arguments
  - Appel système / fonction cible
- [ ] Encoder la chaîne dans le payload

**RESULT:**
```
☐ PASS | ☐ FAIL
Nombre de gadgets : ___
Chaîne complète : ☐ OUI
Objectif de la chaîne : _______________
```

---

### Étape 30 : Payload Development

**TODO:**
- [ ] Définir l'objectif : reverse shell, code exec, persistence
- [ ] Développer le shellcode ou la commande
- [ ] Encoder si nécessaire (bad chars)
- [ ] Tester le payload isolément

**RESULT:**
```
☐ PASS | ☐ FAIL
Type payload : _______________
Taille : ___ bytes
Payload testé : ☐ OUI
```

---

### Étape 30.3 : Second Bug for Sandbox Escape

**TODO:**
- [ ] Si sandboxé, identifier bug d'escape :
  - [ ] Kernel vuln
  - [ ] IPC vuln  
  - [ ] Confused deputy
  - [ ] File descriptor leak
  - [ ] Binder vuln
- [ ] Répéter Phase A-F pour ce 2ème bug

**RESULT:**
```
☐ PASS | ☐ FAIL | ☐ N/A (pas sandboxé)
Bug escape identifié : ☐ OUI | ☐ NON
Type : _______________
Validé : ☐ OUI | ☐ NON
```

---

### Étape 30.5 : Sandbox Escape Implementation

**TODO:**
- [ ] Développer l'exploit du 2ème bug
- [ ] Intégrer avec l'exploit principal
- [ ] Définir le pivot vers process privilégié
- [ ] Tester la chaîne complète

**RESULT:**
```
☐ PASS | ☐ FAIL | ☐ N/A
Escape implémenté : ☐ OUI | ☐ NON
Privilèges obtenus : _______________
```

---

## PHASE H : INTÉGRATION ET TEST

---

### Étape 31 : Exploit Assembly

**TODO:**
- [ ] Assembler tous les composants dans l'input malicieux :
  - Trigger data
  - Heap spray data
  - Leak mechanism
  - ROP chain
  - Payload
- [ ] Vérifier l'intégrité de l'input

**RESULT:**
```
☐ PASS | ☐ FAIL
Input exploit final : _______________
Taille : ___ bytes
Tous composants intégrés : ☐ OUI
```

---

### Étape 32 : Test End-to-End sur Émulateur

**TODO:**
- [ ] Configurer émulateur identique à la cible
- [ ] Exécuter l'exploit complet
- [ ] Vérifier chaque étape de la chaîne
- [ ] Confirmer l'exécution du payload

**RESULT:**
```
☐ PASS | ☐ FAIL
Émulateur : _______________
Exploit réussi : ☐ OUI | ☐ NON
Payload exécuté : ☐ OUI | ☐ NON
```

---

### Étape 32.5 : Failure Analysis

**TODO:**
- [ ] Si échec, identifier la cause :
  - [ ] Timing
  - [ ] Layout heap incorrect
  - [ ] Version différente
  - [ ] Mitigation non bypassée
  - [ ] Autre : ___
- [ ] Ajuster et réitérer

**RESULT:**
```
☐ PASS (succès) | ☐ RETRY (ajustement) | ☐ FAIL (blocage)
Cause d'échec : _______________
Correction appliquée : _______________
```

---

### Étape 33 : Test End-to-End sur Device Rooté

**TODO:**
- [ ] Préparer device rooté pour debug facile
- [ ] Transférer l'exploit
- [ ] Exécuter via vecteur d'attaque
- [ ] Monitor avec debugger/frida
- [ ] Confirmer le succès

**RESULT:**
```
☐ PASS | ☐ FAIL
Device : _______________
Exploit réussi : ☐ OUI | ☐ NON
Payload exécuté : ☐ OUI | ☐ NON
```

---

### Étape 34 : Test End-to-End sur Device Non-Rooté

**TODO:**
- [ ] Utiliser device stock, non modifié
- [ ] Conditions réelles (pas de debug)
- [ ] Exécuter l'exploit
- [ ] Vérifier le succès via side-effects

**RESULT:**
```
☐ PASS | ☐ FAIL
Device : _______________
OS version : _______________
Exploit réussi : ☐ OUI | ☐ NON
Preuve de succès : _______________
```

---

### Étape 35 : Test via Vecteur Réel

**TODO:**
- [ ] Tester via le vecteur réel choisi :
  - [ ] Envoi MMS
  - [ ] Envoi email avec pièce jointe
  - [ ] Ouverture via Gallery
  - [ ] Download via browser
  - [ ] Autre : ___
- [ ] Confirmer 0-click ou 1-click

**RESULT:**
```
☐ PASS | ☐ FAIL
Vecteur testé : _______________
Type : ☐ 0-CLICK | ☐ 1-CLICK
Exploit réussi : ☐ OUI | ☐ NON

*** POC FONCTIONNEL ATTEINT ***
```

---

## PHASE I : STABILISATION ET PORTABILITÉ

---

### Étape 36 : Reliability Testing

**TODO:**
- [ ] Exécuter l'exploit N fois (N ≥ 20)
- [ ] Compter les succès
- [ ] Calculer le taux de fiabilité
- [ ] Identifier les patterns d'échec

**RESULT:**
```
☐ PASS | ☐ FAIL
Tests effectués : ___
Succès : ___
Taux de fiabilité : ___%
Acceptable (>50%) : ☐ OUI | ☐ NON
```

---

### Étape 37 : Stabilisation

**TODO:**
- [ ] Analyser les causes d'échec
- [ ] Améliorer :
  - [ ] Timing (delays, retries)
  - [ ] Heap spray (plus de spray)
  - [ ] Retry logic
  - [ ] Fallback paths
- [ ] Re-tester après chaque amélioration

**RESULT:**
```
☐ PASS | ☐ FAIL
Améliorations appliquées : _______________
Nouveau taux de fiabilité : ___%
```

---

### Étape 38 : Portabilité

**TODO:**
- [ ] Lister les versions OS cibles
- [ ] Lister les modèles de devices cibles
- [ ] Adapter l'exploit pour chaque variante :
  - Offsets
  - Gadgets
  - Allocateur
- [ ] Tester sur chaque cible

**RESULT:**
```
☐ PASS | ☐ FAIL
Cibles supportées :
- [ ] Version ___ sur ___
- [ ] Version ___ sur ___
- [ ] Version ___ sur ___
```

---

### Étape 39 : Edge Cases

**TODO:**
- [ ] Tester les cas limites :
  - [ ] Batterie faible (<20%)
  - [ ] Mémoire limitée
  - [ ] Interruptions (appel entrant)
  - [ ] Mode avion
  - [ ] Multitasking intensif
- [ ] Documenter les limitations

**RESULT:**
```
☐ PASS | ☐ FAIL
Edge cases testés : ___
Limitations identifiées : _______________
```

---

## PHASE J : DOCUMENTATION

---

### Étape 40 : Write-up Technique

**TODO:**
- [ ] Documenter la chaîne complète :
  - Analyse du bug (depuis décompilation)
  - Validation et calculs
  - Développement de l'exploit
  - Bypass des mitigations
  - Résultats et statistiques
- [ ] Inclure code et fichiers

**RESULT:**
```
☐ PASS | ☐ FAIL
Document : _______________
Pages : ___
Code source inclus : ☐ OUI
```

---

### Étape 41 : CVE Request

**TODO:**
- [ ] Préparer la demande CVE
- [ ] Soumettre à MITRE ou CNA approprié
- [ ] Fournir les détails techniques requis
- [ ] Suivre le processus

**RESULT:**
```
☐ PASS | ☐ FAIL
CVE attribué : ☐ OUI | ☐ NON
Numéro : CVE-____-_____
```

---

### Étape 42 : Responsible Disclosure

**TODO:**
- [ ] Contacter le vendor
- [ ] Envoyer le rapport technique
- [ ] Définir la timeline de disclosure
- [ ] Coordonner le patch

**RESULT:**
```
☐ PASS | ☐ FAIL
Vendor contacté : _______________
Date de contact : _______________
Réponse reçue : ☐ OUI | ☐ NON
Timeline accordée : ___ jours
```

---

### Étape 43 : PoC Final Packagé

**TODO:**
- [ ] Créer le package final :
  - [ ] Exploit fonctionnel
  - [ ] Instructions d'utilisation
  - [ ] Vidéo de démonstration
  - [ ] README complet
- [ ] Archiver proprement

**RESULT:**
```
☐ PASS | ☐ FAIL
Package créé : _______________
Contenu :
- [ ] exploit.xxx
- [ ] README.md
- [ ] demo.mp4
- [ ] writeup.pdf

*** PROJET TERMINÉ ***
```

---

## RÉSUMÉ FINAL

| Phase | Description | Étapes | Statut |
|-------|-------------|--------|--------|
| **A** | Analyse Statique du Code | 1-3 | ☐ |
| **B** | Validation du Bug | 4-10.7 | ☐ |
| **C** | Atteignabilité | 11-13 | ☐ |
| **D** | Environnement | 14-17 | ☐ |
| **E** | PoC Crash | 18-23 | ☐ |
| **F** | Primitive & Stratégie | 24-26.7 | ☐ |
| **G** | Exploit Dev | 27-30.5 | ☐ |
| **H** | Intégration & Test | 31-35 | ☐ |
| **I** | Stabilisation | 36-39 | ☐ |
| **J** | Documentation | 40-43 | ☐ |

---

## QUICK REFERENCE : Patterns de Bugs à Chercher

### Integer Issues
- [ ] Multiplication avant allocation : `malloc(width * height * bpp)`
- [ ] Addition de tailles : `size1 + size2 + header`
- [ ] Cast implicite signé/non-signé
- [ ] Truncation (64→32, 32→16, 16→8)
- [ ] Comparaison signé vs non-signé

### Memory Issues
- [ ] Allocation basée sur input sans validation
- [ ] Boucle avec index contrôlable
- [ ] memcpy/memmove avec taille contrôlable
- [ ] Off-by-one dans les boucles
- [ ] Double free / UAF patterns

### Logic Issues
- [ ] Check bypassable (mauvaise condition)
- [ ] TOCTOU (Time-of-check to time-of-use)
- [ ] State confusion
- [ ] Missing error handling

---

**Date de début :** _______________
**Date de fin :** _______________
**Binaire analysé :** _______________
**Résultat final :** ☐ SUCCÈS | ☐ ÉCHEC

---

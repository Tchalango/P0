# Vulnerability Research Methodology — Checklist v4.4 FULL  
**Binary-only · PoC-first · Reality-proof+++**

> **Scope** : usage **autorisé** (audit interne, bug bounty, recherche responsable).  
> **Objectif** : passer de l’ASM/microcode/pseudocode à un **PoC démontrable** (pas seulement “crash”) malgré les pièges réels : parsing fragile, état caché, ASAN≠prod, contraintes composées, instrumentation perturbatrice, non‑déterminisme, OOM, variations d’environnement.

---

## 0) Règles de pilotage

### 0.1 Identifiants & traçabilité (obligatoire)
- **Bug** : `VULN-YYYY-NNN` (ex. `VULN-2026-001`)
- **Binaire** : `TARGET-<name>-<buildid/hash>`
- **Preuve** : référencée (fichier + outil + timestamp)

### 0.2 Artefacts minimum (sinon FAIL)
Pour marquer une étape **PASS**, produire au minimum :
- 1 note `.md` structurée
- 1 preuve “dure” (ASM/pseudo/microcode/screenshot/log/commande+output)
- 1 lien explicite vers `VULN_ID` + `TARGET_ID`

### 0.3 Timeboxing (recommandé)
> Règle : si tu dépasses **2× le budget**, tu **re-scores** / **pivot**.
| Bloc | Budget indicatif |
|------|------------------|
| Baseline (Phase 0) | 30–90 min |
| Static/Triage (Phase A) | 1–4h / fonction |
| Validation (Phase B) | 2–6h / bug |
| Reachability (Phase C) | 1–4h |
| Format/Parsing (Phase D) | 1–4h |
| PoC (Phase E) | 2–10h |
| Patch diff (10.2) | 1–3h |

### 0.4 Gates (stop criteria)
Si un **gate critique** échoue : **rollback** à l’étape indiquée (pas de fuite en avant).

---

## 1) Niveaux de PoC (IMPORTANT)

> Ça évite l’impasse “pas de crash ⇒ pas de PoC”.

- **PoC‑A (Reach)** : preuve que **fonction + sink** sont atteints + valeurs critiques observées.
- **PoC‑B (Corruption / Oracle)** : preuve de **corruption/invariant cassé** **ou** divergence “oracle” mesurable (sans crash).
- **PoC‑C (Crash)** : crash reproductible (prod‑like idéalement) + proof sink + conditions.

**Règle** : si PoC‑C est dur, vise PoC‑B (souvent suffisant pour un rapport solide).

---

## 2) Notation standard (annotations rapides)

### 2.1 Tags inline
- Sinks : `[SINK:OOBW] [SINK:OOBR] [SINK:UAF] [SINK:TYPECONF] [SINK:RACE] [SINK:LOGIC]`
- Sources : `[SRC:FILE:<fmt>:<field/offset>] [SRC:IPC] [SRC:NET] [SRC:STATE]`
- Transforms : `[CAST:U64→U32] [CAST:SXTW] [CAST:UXTW] [MASK:&0x..] [CLAMP] [LOOKUP]`
- Checks : `[CHECK:<cond>]` + statut `BLOCKING / MAYBE / UNKNOWN`
- `[GATE]` pour les points Go/No‑Go

### 2.2 Contrôlabilité “PARTIEL”
Toujours préciser **quoi** :
- contrôlé : bits / plage / valeurs discrètes
- non contrôlé : clamp/lookup/bits forcés

---

## 3) Layout repo recommandé

```
/targets/<TARGET_ID>/
  metadata.md
  binaries/
  notes/
    repro_script.md
    env_parity.md

/bugs/<VULN_ID>/
  00_summary.md
  01_static.md
  02_validation.md
  03_reachability.md
  04_format_parsing.md
  04_env.md
  05_poc.md
  evidence/
    asm_snippets.txt
    screenshots/
    logs/
  inputs/
    A_reach.bin
    B_trigger.bin
    C_crash.bin
    *.min.bin
triage.csv
triage_ranked.md
```

---

# PHASE 0 — BASELINE (process-level)

## Étape 0 : Baseline + **hash parity** (obligatoire)
**TODO**
- [ ] Identifier : process cible, lib, version OS/patch, modèle device
- [ ] Extraire : hash + build-id + dépendances critiques
- [ ] **Hash parity** : binaire analysé == binaire sur device
- [ ] Golden run : input valide connu → decode OK
- [ ] Script repro minimal (push + trigger + collecte logs)

**RESULT**
```
☐ PASS | ☐ FAIL
TARGET_ID : ____________________________
Build-id/Hash (analysé) : ______________
Hash (device) : ________________________
Hash parity : ☐ OUI | ☐ NON
Process réel de décodage : _____________
Artefacts :
- targets/<TARGET_ID>/metadata.md
- targets/<TARGET_ID>/notes/repro_script.md
[GATE] Hash parity = NON → re-extraire / corriger TARGET_ID
```

## Étape 0.5 : **Environment parity** (cold/warm, flags, configs) ✅
> Anti “même binaire, comportement différent”.

**TODO**
- [ ] Capturer paramètres qui changent le path :
  - [ ] properties / flags / configs
  - [ ] thumbnail/full, cache ON/OFF, HW accel, codecs préférés
  - [ ] options decode (subsample, bounds, EXIF/ICC, etc.)
- [ ] Définir 2 modes :
  - **Cold** : cache vide / état initial
  - **Warm** : cache préchauffé / mêmes appels précédents

**RESULT**
```
☐ PASS | ☐ FAIL
Env snapshot documenté : ☐ OUI | ☐ NON
Artefacts :
- targets/<TARGET_ID>/notes/env_parity.md
```

---

# PHASE A — STATIC + TRIAGE

## Étape 1 : Analyse fonction par fonction
**TODO**
- [ ] Annoter : arithmétique tailles/indices + `[CAST]`
- [ ] Repérer allocations
- [ ] Repérer accès mémoire (read/write) + indexation
- [ ] Repérer copies (memcpy/memmove/loops)
- [ ] Repérer checks + early exits `[CHECK]`
- [ ] Marquer sinks `[SINK:*]`

**RESULT**
```
☐ PASS | ☐ FAIL
Fonction : _____________________________
RVA/VA : 0x_____________________________
Sinks : _________________________________
Patterns : ______________________________
Artefacts :
- bugs/<VULN_ID>/01_static.md
- bugs/<VULN_ID>/evidence/asm_snippets.txt
```

## Étape 2 : Fiches “bug potentiel”
**TODO**
- [ ] Décrire : type, variables, types hypothétiques
- [ ] `[SRC:*]` hypothétique
- [ ] `[SINK:*]` précis
- [ ] Reachability hypothétique (entry points/handlers)

**RESULT**
```
☐ PASS | ☐ FAIL
Bugs identifiés : ______
Format : {id, fonction, addr, sink, type, source_hyp, confiance, notes}
Artefacts :
- triage.csv
- bugs/<VULN_ID>/00_summary.md (si retenu)
```

## Étape 3 : Priorisation PoC-first (R domine)
**TODO**
- [ ] Scorer (0–5) :
  - C = Confiance statique
  - I = Impact potentiel
  - R = Reachability estimée
  - K = Complexité
- [ ] Filtre : `if R == 0: skip` (sauf justification)
- [ ] Score : `S = C + 2*I + 3*R - K`
- [ ] Top 3–5

**RESULT**
```
☐ PASS | ☐ FAIL
Top bugs : _____________________________
Bug sélectionné : ______________________
Artefacts : triage_ranked.md
```

## Étape 3.5 : Quick Reach Sanity (5–15 min) ✅
> Évite 2h de validation sur du code mort.

**TODO**
- [ ] Hook/trace minimal sur la fonction candidate
- [ ] Lancer golden + 1–2 variations rapides
- [ ] **Hit-rate** : touches / N runs (ex. 8/10)
- [ ] Note anti-debug/anti-hook + side-effects possibles (timing/layout)

**RESULT**
```
☐ PASS | ☐ FAIL
Touché : ☐ OUI | ☐ NON
Hit-rate : ___/___
Anti-debug suspecté : ☐ OUI | ☐ NON | ☐ INCONNU
Action :
- si NON → R=0, SKIP (retour Étape 3)
- si OUI → Phase B
Artefacts :
- bugs/<VULN_ID>/evidence/logs/quick_reach.log
```

---

# PHASE B — VALIDATION TECHNIQUE (preuves statiques)

## Étape 4 : ASM vs pseudo (fidélité)
**TODO**
- [ ] Instruction(s) fautive(s) (ASM)
- [ ] W/X + extends (SXTW/UXTW) + truncations
- [ ] ABI : arguments du sink (dest/src/len)

**RESULT**
```
☐ PASS | ☐ FAIL
Bug confirmé : ☐ OUI | ☐ DOUTE | ☐ NON
Artefacts : bugs/<VULN_ID>/02_validation.md (ASM proof)
[GATE] DOUTE persistante → retour Étape 1–2
```

## Étape 5 : Backward slicing (depuis le SINK)
**TODO**
- [ ] Remonter len/index/dest/base
- [ ] Lister transformations `[CAST]/[MASK]/[CLAMP]/[LOOKUP]`
- [ ] Identifier `[SRC:*]` probable

**RESULT**
```
☐ PASS | ☐ FAIL
Dataflow : SOURCE → … → SINK
Variables critiques : ____________________
Artefacts : 02_validation.md (Backward slice)
```

## Étape 6 : Taint (contrôlabilité)
**TODO**
- [ ] SOURCE (champ/offset/param/état)
- [ ] Contrôle : OUI/NON/PARTIEL (détails concrets)
- [ ] Transformations

**RESULT**
```
☐ PASS | ☐ FAIL
SOURCE : ________________________________
Contrôle : ☐ OUI | ☐ NON | ☐ PARTIEL (détails)
Artefacts : 02_validation.md (Taint)
```

## Étape 7 : Checks (exhaustif)
**TODO**
- [ ] Lister tous les `[CHECK]` entre SOURCE et SINK
- [ ] Classer : BLOCKING / MAYBE / UNKNOWN
- [ ] Noter early exits

**RESULT**
```
☐ PASS | ☐ FAIL
Nb checks : ______
Checks bloquants : ______
Artefacts : 02_validation.md (Checks)
[GATE] Bloquant systématique → retour Étape 3
```

## Étape 8 : Contraintes & triggers (avec dépendances)
**TODO**
- [ ] Types exacts (ASM) + limites (wrap/trunc)
- [ ] Calculer 1–3 triggers réalistes
- [ ] Nb contraintes interdépendantes : ______
- [ ] Si > 3 → Z3/solver : ☐ OUI | ☐ SKIP (justifier)

**RESULT**
```
☐ PASS | ☐ FAIL
Triggers : _______________________________
Nb contraintes : ______  Solver : ☐ OUI | ☐ NON
Artefacts : 02_validation.md (Constraints)
```

## Étape 9 : Allocation vs accès + attente de crash
**TODO**
- [ ] Taille allouée vs taille/index accédé
- [ ] Quantifier dépassement
- [ ] Estimer “crashabilité” :
  - adjacent : metadata / autre objet / padding / unmapped / inconnu
  - crash attendu : immédiat / différé / corruption silencieuse

**RESULT**
```
☐ PASS | ☐ FAIL
Alloc : ______  Accès : ______  OOB : ______
Crash attendu : __________________________
Artefacts : 02_validation.md (Alloc vs Access)
```

## Étape 10 : Verdict technique (GO/NO-GO)
**TODO**
- [ ] Résumer 4–9 (10 lignes max)
- [ ] Conditions exactes (checks + triggers + parsing)
- [ ] CWE + confiance

**RESULT**
```
☐ GO → Phase C
☐ NO-GO → Retour Étape 3
☐ PARTIEL → Documenter limites
Artefacts : 02_validation.md (Verdict)
```

## Étape 10.2 : Patch diffing (recommandé)
**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Patché : ☐ OUI | ☐ NON
Pattern de fix : ________________________
Artefacts : 02_validation.md (Patch diff)
```

---

# PHASE C — ATTEIGNABILITÉ (function-level)

## Étape 11 : Call graph (statique) + VM/JIT
**TODO**
- [ ] Remonter vers entry points (exports/JNI/handlers/registries)
- [ ] VM/JIT suspecté : ☐ OUI | ☐ NON | ☐ INCONNU (si OUI → traces runtime prioritaires)

**RESULT**
```
☐ PASS | ☐ FAIL
Entry points : ___________________________
Chemin court : ___________________________
Artefacts : 03_reachability.md (Call graph)
```

## Étape 11.5 : Proof-of-Reach (OBLIGATOIRE) + hit-rate cold/warm ✅
**TODO**
- [ ] Confirmer fonction atteinte avec input valide
- [ ] Logger args critiques (sizes/flags)
- [ ] Mesurer **hit-rate** sur N runs :
  - cold : ___/___
  - warm : ___/___
- [ ] Noter anti-debug/side-effects

**RESULT**
```
☐ PASS | ☐ FAIL
Fonction atteinte : ☐ OUI | ☐ NON
Hit-rate cold : ___/___  warm : ___/___
Artefacts : evidence/logs/reach.log
[GATE] NON → retour Étape 11/12/13
[GATE] <80% → traiter non-déterminisme (Étape 19.2 + 12.6)
```

## Étape 12 : Trigger conditions + hidden state
**TODO**
- [ ] Conditions runtime : format/headers/flags, thumbnail vs full, caches, bornes
- [ ] Hidden state :
  - [ ] globals/statiques lues
  - [ ] modes/flags dérivés d’autres champs
  - [ ] dépendances d’ordre d’appels (init/warmup)
  - [ ] dépendances externes (DB/scan/metadata store)
- [ ] Construire un input minimal stable (A_reach)

**RESULT**
```
☐ PASS | ☐ FAIL
A_reach créé : ☐ OUI | ☐ NON
Artefacts :
- 03_reachability.md (Trigger + hidden state)
- inputs/A_reach.bin
```

## Étape 12.6 : Checkpoint Map (où ça casse exactement) ✅
**TODO**
- [ ] Définir des checkpoints (stages parsing / sous-fonctions / checks clés)
- [ ] Pour chaque run : dernier checkpoint atteint + raison (check fail / alloc fail / état)
- [ ] Table : variant → last_checkpoint → reason → args observés

**RESULT**
```
☐ PASS | ☐ FAIL
Checkpoint map : ☐ OUI | ☐ NON
Artefacts :
- evidence/logs/checkpoint_map.md
```

## Étape 13 : Entry point mapping (vecteurs)
**TODO**
- [ ] Lister vecteurs (gallery/scanner/browser/mail/…)
- [ ] Pour chacun : permissions, interaction user, contraintes
- [ ] Choisir meilleur vecteur PoC

**RESULT**
```
☐ PASS | ☐ FAIL
Vecteur choisi : _________________________
Artefacts : 03_reachability.md (Entry mapping)
```

---

# PHASE D — FORMAT & PARSING SURVIVAL (anti “OOM early exit”)

## Étape 15 : Format mapping + endianness/alignment
**TODO**
- [ ] Documenter ordre de parsing + dépendances
- [ ] Endianness : ☐ LE | ☐ BE | ☐ mixed
- [ ] Alignment requirements : __________________
- [ ] Identifier “kill-switch fields” (OOM/early exit/checks)

**RESULT**
```
☐ PASS | ☐ FAIL
Mapping produit : ☐ OUI | ☐ NON
Artefacts : 04_format_parsing.md (Format mapping)
```

## Étape 15.5 : Parsing Survival Window (fenêtre de valeurs) ✅
**TODO**
- [ ] Champs lus **avant sink** dépendant du trigger
- [ ] Pré-checks/allocations/tables init déclenchés
- [ ] Fenêtre : trigger_min..trigger_max où parsing survit ET bug triggeable

**RESULT**
```
☐ PASS | ☐ FAIL
Fenêtre survie : _________________________
Champs bloquants : _______________________
Artefacts : 04_format_parsing.md (Survival window)
```

## Étape 15.6 : Survival Search Loop (procédure de convergence) ✅
**TODO**
- [ ] Définir un paramètre d’intensité `t` (ex. width/height/len)
- [ ] Rampe progressive (paliers + logs checkpoints)
- [ ] Si casse : bisection entre dernier OK et premier FAIL
- [ ] Résultat : `t_min_trig`, `t_max_survive`, delta exploitable

**RESULT**
```
☐ PASS | ☐ FAIL
t_min_trig : ______  t_max_survive : ______
Delta exploitable : ______
Artefacts :
- evidence/logs/survival_loop.log
- 04_format_parsing.md (Search loop)
```

## Étape 15.7 : Input Minimization (ddmin) ✅
> Une fois A/B/C obtenus, réduire l’input pour supprimer le bruit.

**TODO**
- [ ] Minimiser A_reach en conservant Reach + args
- [ ] Minimiser B_trigger en conservant Proof-of-SINK
- [ ] Minimiser C_crash (ou PoC‑B) en conservant le signal
- [ ] Conserver avant/après + delta

**RESULT**
```
☐ PASS | ☐ FAIL
Minimisation A/B/C : ☐ OUI | ☐ NON
Artefacts :
- inputs/A_reach.min.bin
- inputs/B_trigger.min.bin
- inputs/C_crash.min.bin (si applicable)
- evidence/logs/minimize.md
```

---

# PHASE ENV — Mitigations / Heap (optionnelle mais utile)

## Étape 14 : Mitigations (haut niveau)
**TODO**
- [ ] Lister : ASLR/CFI/PAC/MTE/SELinux/sandbox…
- [ ] Impact sur PoC/observabilité (pas “exploit”)

**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Mitigations : ____________________________
Artefacts : 04_env.md
```

## Étape 16 : Heap / allocateur (utile si ASAN≠prod)
**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Allocateur : _____________________________
Artefacts : 04_env.md (Heap)
```

---

# PHASE E — PoC (A/B/C)

## Étape 18 : Inputs A/B/C
**TODO**
- [ ] A = reach stable (minimizable)
- [ ] B = trigger partiel (survit parsing, atteint sink)
- [ ] C = crash (si possible)

**RESULT**
```
☐ PASS | ☐ FAIL
A_reach : _______________________________
B_trigger : _____________________________
C_crash : _______________________________
Artefacts : inputs/A_reach.bin, B_trigger.bin, C_crash.bin
```

## Étape 18.5 : Proof-of-SINK + hit-rate ✅
**TODO**
- [ ] Hook/log juste avant sink (ou sur memcpy/store)
- [ ] Valeurs observées (len/index/dest) cohérentes avec calculs
- [ ] Hit-rate : ___/___ (cold/warm si utile)

**RESULT**
```
☐ PASS | ☐ FAIL
SINK exécuté : ☐ OUI | ☐ NON
Hit-rate : ___/___
Valeurs : ________________________________
Artefacts : evidence/logs/sink_reach.log
[GATE] NON → retour Étape 12/15.6/18 + checkpoint map
```

## Étape 18.7 : Proof-of-Corruption (PoC‑B) ✅
> À utiliser quand sink=OUI mais pas de crash.

**TODO**
- [ ] Définir un invariant post-sink (magic/size/checksum/state/compteur)
- [ ] Capturer before/after minimal (objet/état)
- [ ] Démontrer divergence reproductible (N runs)

**RESULT**
```
☐ PASS | ☐ FAIL
Corruption prouvée : ☐ OUI | ☐ NON
Invariant cassé : ________________________
Repro : ___/___
Artefacts :
- evidence/logs/corruption_proof.log
- 05_poc.md (Corruption proof)
[GATE] PASS → PoC‑B atteint
```

## Étape 18.8 : Oracle / Differential Proof (PoC‑B) ✅
> Quand pas d’invariant interne simple, utiliser un oracle externe mesurable.

**TODO**
- [ ] Définir un oracle :
  - [ ] hash/CRC output (bitmap/frames)
  - [ ] dims/stride invariants
  - [ ] return codes attendus
  - [ ] comparaison à un décodeur de référence (si applicable)
- [ ] Mesurer divergence A vs B (ou runs) de manière reproductible

**RESULT**
```
☐ PASS | ☐ FAIL
Oracle défini : ☐ OUI | ☐ NON
Divergence reproductible : ___/___
PoC‑B via oracle : ☐ OUI | ☐ NON
Artefacts : evidence/logs/oracle_proof.md
```

## Étape 19 : Crash validation — ASAN vs prod (gate réaliste)
**TODO**
- [ ] Run sanitizer (si possible)
- [ ] Run prod-like (sans sanitizer)
- [ ] Comparer : path, heap layout, checks, early exits

**Règles de PASS**
- PASS si **prod-like crash = OUI** → PoC‑C
- PASS si **ASAN crash = OUI** + **Proof-of-SINK = OUI** + (au moins un) :
  - Proof-of-Corruption/Oracle = OUI (PoC‑B), ou
  - explication argumentée du “prod ne crashe pas” + preuves
- FAIL si ASAN crash sans proof-of-sink (retour 18.5)

**RESULT**
```
☐ PASS | ☐ FAIL
Crash sanitizer : ☐ OUI | ☐ NON | ☐ N/A
Crash prod-like : ☐ OUI | ☐ NON
PoC atteint : ☐ A | ☐ B | ☐ C
Artefacts :
- evidence/logs/asan.txt (si applicable)
- evidence/logs/prod_run.txt
- 05_poc.md (ASAN vs prod)
```

## Étape 19.2 : Non-determinism Control (hit-rate < 80% / flakiness) ✅
**TODO**
- [ ] Séparer runs cold vs warm
- [ ] Répéter N fois : mesurer variance (reach/sink/oracle/checkpoints)
- [ ] Si race suspectée : documenter symptômes (timing sensitivity, variance)
- [ ] Stabiliser via contrôle d’état/caches (sans “guérir” le bug)

**RESULT**
```
☐ PASS | ☐ FAIL
Variance quantifiée : ☐ OUI | ☐ NON
Cause probable : ☐ state | ☐ race | ☐ heap | ☐ instrumentation | ☐ inconnu
Artefacts : evidence/logs/nondet.md
```

## Étape 19.3 : Resource Monitoring (OOM/hang/timeout) ✅
**TODO**
- [ ] Sur chaque run : pic mémoire (ou indicateur), durée, timeouts, codes d’erreur
- [ ] Catégoriser : OOM vs check fail vs hang vs silent

**RESULT**
```
☐ PASS | ☐ FAIL
Catégorie : ☐ OOM | ☐ CHECK | ☐ HANG | ☐ SILENT | ☐ OTHER
Artefacts : evidence/logs/resources.md
```

## Étape 20 : Crash sur device réel (preuve “target-grade”)
**TODO**
- [ ] Trigger via vecteur choisi
- [ ] Capturer tombstone/logs

**RESULT**
```
☐ PASS | ☐ FAIL
Crash device : ☐ OUI | ☐ NON
Tombstone : ☐ OUI | ☐ NON
Artefacts : evidence/logs/tombstone.txt
```

## Étape 20.5 : Fuzzing confirmation (souvent recommandé)
**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Fuzzer : ________________________________
Crashes uniques : ______
Artefacts : evidence/logs/fuzz_summary.md
```

---

## Gates de fin (v4.4)

- **PoC‑A atteint** si : (11.5 PASS) + (18.5 PASS) + hit-rate mesuré
- **PoC‑B atteint** si : (18.7 PASS) **ou** (18.8 PASS)
- **PoC‑C atteint** si : prod-like crash PASS (ou sanitizer crash + PoC‑B + justification)

---

## Rollback rapide (si “ça marche pas”)

```
Reach=NON                → Étape 11/12/13 (+ 0.5 env parity)
Reach=OUI, Sink=NON       → Étape 12 + 12.6 + 15.6 + 18 (input)
Sink=OUI, valeurs ≠ calc  → Étape 8 (types/contraintes/endianness) + 15
Sink=OUI, pas de crash    → Étape 18.7/18.8 (PoC-B) + 9/16 (crashabilité/heap)
Flaky (<80%)              → Étape 19.2 (non-det) + 0.5 + 12.6
OOM/hang/timeout           → Étape 19.3 + 15.5/15.6
Binaire différent          → Étape 0 (hash parity) + 10.2
```

---

## Annexes

### A1 — Colonnes recommandées `triage.csv`
```
vuln_id,target_id,function,addr,sink,source_hyp,type,cwe,C,I,R,K,score,status,notes
```

### A2 — Template “Checkpoint Map” (12.6)
```
variant | run_id | cold/warm | last_checkpoint | reason | reach? | sink? | len/index observed | notes
```

### A3 — Template “Oracle Proof” (18.8)
```
input | run_id | output_hash | dims/stride | return_code | divergence? | notes
```

### A4 — Template `bugs/<VULN_ID>/00_summary.md`
```
# <VULN_ID> — <Titre court>

## Target
- TARGET_ID:
- Hash (analysé):
- Hash (device):
- Hash parity:
- Device/OS:
- Process:
- Env parity (cold/warm): (lien)

## Résumé
- Type / CWE:
- Impact:
- Confiance:

## Reach / Sink / Corruption
- Proof-of-Reach (hit-rate cold/warm):
- Proof-of-SINK (hit-rate):
- Proof-of-Corruption (hit-rate) / Oracle proof:
- PoC atteint : A / B / C

## Triggers / Parsing survival
- Triggers:
- Fenêtre survie (min..max):
- Search loop (15.6) résultats:
- Endianness/alignment:

## Checks / Hidden state
- Checks:
- Hidden state:

## PoC artefacts
- A_reach (+ min):
- B_trigger (+ min):
- C_crash (+ min):
- ASAN vs prod:
- Logs/tombstone:
```

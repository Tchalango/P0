# Plan de Transition : Analyste Sécurité → Chercheur en Vulnérabilités

## Situation actuelle
- 12 ans à la Confédération (analyste sécurité)
- Skills réels : fuzzing avancé, QBDI, Frida, DynamoRIO, recherche zero-click
- LinkedIn mort depuis 12 ans
- Aucune visibilité publique
- Objectif : job niveau Project Zero / Trail of Bits / UBS Red Team

---

## PHASE 1 : FONDATIONS (Semaines 1-4)

### Semaine 1 : LinkedIn - Refonte complète

#### Nouveau Headline (titre)
```
Security Researcher | Vulnerability Research | Fuzzing & Binary Analysis | QBDI • Frida • DynamoRIO
```

#### Nouveau Résumé (About)
```
Chercheur en sécurité spécialisé dans la recherche de vulnérabilités et le fuzzing avancé.

Après 12 ans d'expérience en sécurité informatique, je me concentre maintenant sur :

🔬 Recherche de vulnérabilités
• Fuzzing coverage-guided avec instrumentation dynamique (QBDI, Frida, DynamoRIO)
• Analyse de binaires Windows x64 et Android ARM64
• Détection de vulnérabilités : buffer overflows, type confusion, integer overflows

⚙️ Développement d'outils
• Harnais de fuzzing personnalisés atteignant 80-100k exécutions/seconde
• Instrumentation pour capture de couverture basic block et comparaisons
• Intégration libFuzzer pour fuzzing de librairies natives

🎯 Domaines de recherche
• Sécurité mobile (Android native libraries)
• Sécurité Windows (DLLs, drivers)
• Traitement d'images et formats de fichiers

Basé à Genève, Suisse | Ouvert aux opportunités remote EU

📧 [ton email]
🔗 [ton GitHub quand il sera prêt]
```

#### Expérience - Réécriture

**AVANT (ce que tu as probablement) :**
```
Analyste Sécurité
Confédération Suisse
2013 - 2025
- Analyse de vulnérabilités
- Gestion des incidents
```

**APRÈS :**
```
Analyste Sécurité Senior
Confédération Suisse
2013 - 2025

Responsable de l'analyse de sécurité et de la gestion des vulnérabilités 
pour l'infrastructure fédérale.

• Évaluation et priorisation des vulnérabilités sur des systèmes critiques
• Coordination de la remédiation avec les équipes techniques
• Veille technologique et analyse des menaces émergentes

En parallèle, développement d'expertise en recherche offensive :
• Développement d'outils de fuzzing avec instrumentation dynamique
• Recherche de vulnérabilités sur des cibles mobiles et Windows
• Analyse statique et dynamique de binaires
```

#### Skills à ajouter (dans l'ordre)
1. Vulnerability Research
2. Fuzzing
3. Binary Analysis
4. Reverse Engineering
5. QBDI
6. Frida
7. Dynamic Binary Instrumentation
8. Windows Security
9. Android Security
10. C/C++
11. Python
12. x86/x64 Assembly
13. ARM Assembly
14. libFuzzer
15. AFL

### Semaine 2 : GitHub - Setup

#### Créer un profil propre
- Photo pro (ou pas de photo, c'est ok en sécu)
- Bio : "Security Researcher | Fuzzing | Binary Analysis"
- Location : Geneva, Switzerland
- Lien vers LinkedIn

#### Premier repo (même petit)
Idées de repos "quick win" :
1. **qbdi-coverage** - Ton wrapper QBDI pour la couverture
2. **windows-fuzzing-harness** - Template de harnais pour DLLs Windows
3. **semgrep-type-confusion** - Tes règles de détection

Structure minimale :
```
repo-name/
├── README.md (bien écrit, avec screenshots)
├── src/
├── examples/
└── LICENSE (MIT ou Apache 2.0)
```

### Semaine 3-4 : Premier contenu technique

#### Option A : Blogpost
Plateforme : GitHub Pages (gratuit, simple) ou Medium

Sujet suggéré :
```
"Fuzzing Windows DLLs with QBDI and libFuzzer: A Practical Guide"

1. Introduction - Pourquoi QBDI sur Windows
2. Setup - Cross-compilation depuis Linux
3. Instrumentation - Capture de coverage
4. Intégration libFuzzer
5. Résultats et performances
6. Conclusion
```

#### Option B : Write-up d'une vuln (si tu en as une reportable)
- Description du bug
- Méthodologie de découverte
- Impact
- Timeline de disclosure

---

## PHASE 2 : VISIBILITÉ (Semaines 5-12)

### Mois 2 : Accumulation

#### Objectifs
- [ ] 1 CVE soumis (même mineur)
- [ ] 2ème blogpost ou repo
- [ ] Connexions LinkedIn actives (chercheurs sécu, recruteurs)

#### Cibles faciles pour CVE
- Librairies open-source de parsing (images, documents)
- Projets Android AOSP moins audités
- Outils de développement Windows

#### Engagement LinkedIn
- Commenter les posts de chercheurs connus
- Partager tes blogposts
- Rejoindre les groupes : "Information Security", "Offensive Security"

### Mois 3 : Récolte

#### Candidatures actives
Postuler à (dans cet ordre de priorité) :

**Tier 1 - Le rêve**
| Entreprise | Poste | Lien |
|------------|-------|------|
| Google Zurich | Security Engineer, Cloud Vulnerability Research | careers.google.com |
| Google | Project Zero (si ouvert) | careers.google.com |
| Trail of Bits | Security Engineer | trailofbits.com/careers |
| Exodus Intelligence | Browser/Mobile Researcher | exodusintel.com/careers |

**Tier 2 - Excellent**
| Entreprise | Poste | Lien |
|------------|-------|------|
| Microsoft MSRC | Security Researcher | careers.microsoft.com |
| UBS Zurich | Red Team Operator | jobs.ubs.com |
| UBS Zurich | Cyber Threat Hunter | jobs.ubs.com |
| Apple SEAR | Security Engineer | apple.com/careers |

**Tier 3 - Solide, en Suisse**
| Entreprise | Poste | Localisation |
|------------|-------|--------------|
| Orange Cyberdefense | Pentester Senior | Morges/Genève |
| Kudelski Security | Security Researcher | Cheseaux |
| Swisscom | Security Operations Engineer | Zurich/Bern |
| SIX Group | Security Engineer | Zurich |
| Pictet | Cybersecurity Analyst | Genève |

#### Insomni'hack 2026
- CFP généralement en automne
- Soumettre un talk basé sur ta recherche
- Même si refusé, t'auras préparé du contenu

---

## PHASE 3 : NÉGOCIATION (Mois 4-6)

### Pendant le chômage

#### Timeline optimale
```
Mois 1-2 chômage : Finaliser portfolio, postuler massivement
Mois 3-6 chômage : Entretiens, négociations
Mois 6-12 chômage : Buffer si nécessaire
Mois 12-18 chômage : Dernier recours / pivot
```

#### Attentes salariales (Suisse)
| Type de poste | Fourchette CHF |
|---------------|----------------|
| Google Zurich L4-L5 | 180-280k |
| UBS Red Team Senior | 140-180k |
| Consulting (SCRT/Kudelski) | 120-160k |
| Remote US (Trail of Bits) | $150-200k USD |

---

## CHECKLIST AVANT DÉMISSION

- [ ] LinkedIn refait
- [ ] GitHub avec au moins 1 repo
- [ ] 1 blogpost publié
- [ ] 5-10 candidatures envoyées
- [ ] Au moins 1 entretien passé (pour tester)
- [ ] Budget familial calculé pour 18 mois

---

## MESSAGES TYPE

### Message LinkedIn pour connexion (recruteur)
```
Bonjour [Prénom],

Je suis chercheur en sécurité spécialisé en fuzzing et analyse de vulnérabilités, 
basé à Genève. Je vois que vous recrutez pour [Entreprise] - 
je serais intéressé à discuter des opportunités en security research.

Cordialement,
[Ton prénom]
```

### Email de candidature spontanée
```
Subject: Security Researcher - Vulnerability Research & Fuzzing

Bonjour,

Je suis un chercheur en sécurité avec 12 ans d'expérience, spécialisé dans :
- Fuzzing avancé avec instrumentation dynamique (QBDI, Frida, DynamoRIO)
- Recherche de vulnérabilités sur Windows x64 et Android
- Développement de harnais de fuzzing (80-100k exec/sec)

J'ai récemment travaillé sur [ton projet le plus impressionnant].

Mon profil : [LinkedIn] | [GitHub]

Je suis disponible pour un échange à votre convenance.

Cordialement,
[Prénom Nom]
```

---

## RESSOURCES

### Blogs à suivre (pour rester à jour)
- Google Project Zero Blog
- Trail of Bits Blog
- MSRC Blog
- Azeria Labs (ARM)
- j00ru's blog

### Conférences à viser
- Insomni'hack (Genève) - Mars
- OffensiveCon (Berlin) - Février
- Hexacon (Paris) - Octobre
- REcon (Montréal) - Juin

### Certifications (optionnel, pas prioritaire)
- OSCP (si tu veux, mais tes skills le dépassent)
- OSCE3 (plus pertinent pour ton niveau)
- GXPN / GREM (SANS, cher mais reconnu)

---

## LE PITCH - VERSION FINALE

> "Après 12 ans en sécurité opérationnelle, j'ai développé une expertise pointue en recherche de vulnérabilités. Je construis des infrastructures de fuzzing sur mesure utilisant QBDI pour l'instrumentation dynamique, atteignant 80-100k exécutions par seconde. J'ai appliqué cette méthodologie à la recherche zero-click sur des librairies de traitement d'images, identifiant des vulnérabilités critiques incluant buffer overflows et type confusions. Je cherche maintenant à rejoindre une équipe où cette expertise aura un impact direct sur la sécurité des produits."

---

*Document créé le 12 janvier 2026*
*Objectif : Transition complète en 6-12 mois*

# Vulnerability Research Methodology — Checklist v4 (Binary-only, PoC-first)

> Objectif : transformer une analyse **ASM/microcode/pseudocode** en **PoC crash reproductible**, avec des *gates* clairs et des artefacts traçables.

---

## Règles globales

### R0 — Identifiants & traçabilité (obligatoire)
- **Chaque bug** : `VULN-YYYY-NNN` (ex. `VULN-2026-001`)
- **Chaque binaire** : `TARGET-<name>-<buildid/hash>`
- **Chaque preuve** doit être référencée (fichier + emplacement + date + outil).

### R1 — Artefacts minimum (sinon FAIL)
Pour marquer une étape **PASS**, tu produis au minimum :
- 1 fichier `.md` (notes structurées)
- 1 preuve “dure” (extrait ASM/pseudo/microcode/screenshot/log/cmd output)
- 1 lien explicite vers l’ID bug + TARGET_ID.

### R2 — Gates (stop criteria)
Si un **gate critique** échoue, tu **reviens** à l’étape indiquée. Pas de fuite en avant.

### R3 — Layout repo recommandé
```
/targets/<TARGET_ID>/
  metadata.md
  binaries/
  notes/

/bugs/<VULN_ID>/
  00_summary.md
  01_static.md
  02_validation.md
  03_reachability.md
  04_env.md
  05_poc.md
  evidence/
    asm_snippets.txt
    screenshots/
    logs/
  inputs/
    template_valid.bin
    poc_crash.bin
triage.csv
triage_ranked.md
```

---

## PHASE 0 — BASELINE (obligatoire avant tout)

### Étape 0 : Baseline cible & versioning
**TODO**
- [ ] Identifier exactement : process cible, lib, version OS/patch, modèle device
- [ ] Extraire : hash + build-id + dépendances critiques (libs chargées)
- [ ] Identifier le **process réel** qui décode (pas “supposé”)
- [ ] Créer un script de repro “vide” (sans PoC) : push input + trigger decode + collecte logs
- [ ] Enregistrer un “golden run” (input valide connu → decode OK)

**RESULT**
```
☐ PASS | ☐ FAIL
TARGET_ID : ____________________________
Build-id / Hash : ______________________
Device/OS : ____________________________
Process réel de décodage : _____________
Artefacts :
- targets/<TARGET_ID>/metadata.md
- targets/<TARGET_ID>/notes/repro_script.md
Gate : si le process réel n’est pas identifié → STOP (corriger baseline)
```

---

## PHASE A — ANALYSE STATIQUE DU CODE

### Étape 1 : Analyse fonction par fonction (statique)
**TODO**
- [ ] Pour chaque fonction candidate, annoter :
  - [ ] Arithmétique sur tailles/indices (mul/add/shift/casts)
  - [ ] Allocations (malloc/new/realloc/arena)
  - [ ] Accès mémoire (read/write) + indexation
  - [ ] Copies (memcpy/memmove/strcpy/loops)
  - [ ] Checks (bounds, null, size, state) + early exits
- [ ] Marquer explicitement les **SINKS** potentiels (write/copy/index/store indirect)

**RESULT**
```
☐ PASS | ☐ FAIL
Fonction : _____________________________
RVA/VA : 0x_____________________________
Sinks repérés : ________________________
Patterns suspects : ____________________
Artefacts :
- bugs/<VULN_ID>/01_static.md (ou notes pré-triage)
- bugs/<VULN_ID>/evidence/asm_snippets.txt
```

---

### Étape 2 : Identification des bugs potentiels (fiches)
**TODO**
- [ ] Pour chaque pattern suspect :
  - [ ] Type (overflow, OOB, UAF, type confusion, race, logic)
  - [ ] Variables impliquées + hypothèse de types
  - [ ] SOURCE hypothétique (field/offset/param)
  - [ ] SINK précis (opération vulnérable)
  - [ ] Hypothèse d’atteignabilité (caller/entry point supposé)
- [ ] Créer une fiche “bug potentiel” (1 bug = 1 fiche)

**RESULT**
```
☐ PASS | ☐ FAIL
Bugs identifiés : ______
Format minimal par bug :
{ id, fonction, addr, sink, type, source_hyp, confiance, notes }
Artefacts :
- triage.csv (1 ligne par bug)
- bugs/<VULN_ID>/00_summary.md (si bug retenu)
```

---

### Étape 3 : Priorisation (score + top N)
**TODO**
- [ ] Scorer chaque bug (0–5) :
  - Confiance statique (C)
  - Impact potentiel (I)
  - Atteignabilité estimée (R)
  - Complexité (K) (plus K est haut, plus c’est dur)
- [ ] Score recommandé : `S = 2*C + 2*I + 2*R - K`
- [ ] Sélectionner top 3–5 pour validation

**RESULT**
```
☐ PASS | ☐ FAIL
Top bugs : _____________________________
Bug sélectionné : ______________________
Justification : ________________________
Artefacts :
- triage_ranked.md
Gate : si R ≤ 1 → éviter sauf intérêt spécial (documenter pourquoi)
```

---

## PHASE B — VALIDATION TECHNIQUE (preuves statiques)

### Étape 4 : Validation ASM vs pseudo (fidélité)
**TODO**
- [ ] Identifier l’instruction exacte fautive (ASM)
- [ ] Vérifier conversions W/X, sign/zero extend, casts implicites
- [ ] Confirmer le mapping ABI : arguments du sink (dest/src/len, etc.)

**RESULT**
```
☐ PASS | ☐ FAIL
Bug confirmé en statique : ☐ OUI | ☐ DOUTE | ☐ NON
Instruction(s) clés : __________________
Types justifiés par ASM : ______________
Artefacts :
- bugs/<VULN_ID>/02_validation.md (section “ASM proof”)
Gate : si DOUTE → approfondir microcode / retomber Étape 1–2
```

---

### Étape 5 : Backward slicing (depuis le SINK)
**TODO**
- [ ] Partir du SINK (write/copy/index/store indirect)
- [ ] Remonter chaque variable (len/index/dest/base)
- [ ] Lister transformations (mask/shift/cast/clamp)
- [ ] Identifier la SOURCE (param, champ fichier, metadata, état)

**RESULT**
```
☐ PASS | ☐ FAIL
SINK : __________________ (func+addr)
Variables critiques : __________________
Chaîne dataflow : SOURCE → … → SINK
Nb fonctions traversées : ______
Artefacts :
- bugs/<VULN_ID>/02_validation.md (section “Backward slice”)
```

---

### Étape 6 : Taint (contrôlabilité)
**TODO**
- [ ] SOURCE : fichier/champ/offset OU IPC/Binder OU autre
- [ ] Contrôlabilité : OUI/NON/PARTIEL (et pourquoi)
- [ ] Documenter transformations et pertes d’info (truncation 64→32 etc.)

**RESULT**
```
☐ PASS | ☐ FAIL
SOURCE contrôlable : ☐ OUI | ☐ NON | ☐ PARTIEL
Champ/offset : ________________________
Transformations : ______________________
Artefacts :
- bugs/<VULN_ID>/02_validation.md (section “Taint”)
```

---

### Étape 7 : Control-flow & checks (liste exhaustive)
**TODO**
- [ ] Lister tous les checks entre SOURCE et SINK
- [ ] Pour chaque check :
  - [ ] condition exacte
  - [ ] dépendance (valeurs / état)
  - [ ] bypass théorique ? (basé sur code, pas sur espoir)
- [ ] Identifier les “early exits” et les contraintes de parsing

**RESULT**
```
☐ PASS | ☐ FAIL
Nb checks : ______
Checks bloquants : ______
Contraintes nécessaires : ______________
Artefacts :
- bugs/<VULN_ID>/02_validation.md (section “Checks”)
Gate : si bloquant systématique → retour Étape 3
```

---

### Étape 8 : Analyse de types & contraintes (calcul)
**TODO**
- [ ] Pour chaque variable critique :
  - [ ] signé/non signé, taille, provenance (ASM)
  - [ ] bornes min/max
  - [ ] comportement limite (wrap/trunc/sxtw/uxtw)
- [ ] Calculer 1–3 triggers réalistes
- [ ] Utiliser un solver si contraintes composées (optionnel)

**RESULT**
```
☐ PASS | ☐ FAIL
Trigger(s) : ___________________________
Calcul détaillé : ______________________
Overflow/underflow : ☐ OUI | ☐ NON
Artefacts :
- bugs/<VULN_ID>/02_validation.md (section “Constraints”)
```

---

### Étape 9 : Allocation vs accès (quantification)
**TODO**
- [ ] Calculer taille allouée (avec trigger)
- [ ] Calculer taille/index accédé (avec trigger)
- [ ] Quantifier l’écart (bytes) + direction (read/write)

**RESULT**
```
☐ PASS | ☐ FAIL
Alloc : ______ bytes
Accès : ______ bytes / index ______
Dépassement : ______ bytes
Type : ☐ OOBR | ☐ OOBW | ☐ UAF | ☐ AUTRE
Artefacts :
- bugs/<VULN_ID>/02_validation.md (section “Alloc vs Access”)
Gate : si dépassement = 0 → NO-GO → Étape 3
```

---

### Étape 10 : Verdict technique (GO/NO-GO)
**TODO**
- [ ] Résumer 4–9 en 10 lignes max
- [ ] Définir conditions exactes de déclenchement
- [ ] Assigner CWE + niveau de confiance

**RESULT**
```
☐ GO → Phase C
☐ NO-GO → Retour Étape 3
☐ PARTIEL → Documenter limites

Type : __________________  CWE : ________________
Conditions : _____________________________________
Artefacts :
- bugs/<VULN_ID>/02_validation.md (section “Verdict”)
```

---

### Étape 10.1 : Root cause + pattern hunting
**TODO**
- [ ] Identifier pourquoi (integer issue / logique / API / race / state)
- [ ] Chercher variantes (fonctions sœurs, helpers, mêmes patterns)
- [ ] Ajouter “bugs frères” au triage si trouvé

**RESULT**
```
☐ PASS | ☐ FAIL
Root cause : ____________________________
Variantes : ☐ OUI (____) | ☐ NON
Artefacts :
- bugs/<VULN_ID>/02_validation.md (section “Root cause”)
```

---

### Étape 10.2 : Patch diffing (recommandé)
**TODO**
- [ ] Obtenir version plus récente du même binaire
- [ ] Diff (BinDiff/Diaphora) sur fonctions clés
- [ ] Déterminer si patché + comment

**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Patché : ☐ OUI | ☐ NON
Pattern de fix : ________________________
Versions affectées : _____________________
Artefacts :
- bugs/<VULN_ID>/02_validation.md (section “Patch diff”)
```

---

## PHASE C — ATTEIGNABILITÉ (gate #1 PoC)

### Étape 11 : Call graph (statique)
**TODO**
- [ ] Construire call graph autour de la fonction vuln
- [ ] Remonter vers points d’entrée : exports, JNI, handlers, registries
- [ ] Documenter au moins 1–2 chemins plausibles

**RESULT**
```
☐ PASS | ☐ FAIL
Entry points candidats : __________________
Chemin le plus court : ____________________
Artefacts :
- bugs/<VULN_ID>/03_reachability.md (section “Call graph”)
```

---

### Étape 11.5 : Proof-of-Reach (dynamique minimale) — OBLIGATOIRE pour viser PoC
**TODO**
- [ ] Instrumentation légère (Frida / tracepoints / DBI)
- [ ] Confirmer “fonction atteinte” avec input valide
- [ ] Logger les args critiques (sizes/flags/champs)

**RESULT**
```
☐ PASS | ☐ FAIL
Fonction atteinte : ☐ OUI | ☐ NON
Trace/Log : _____________________________
Artefacts :
- bugs/<VULN_ID>/evidence/logs/reach.log
Gate : si NON → retour Étape 11/13 (mauvais vecteur/chemin)
```

---

### Étape 12 : Conditions exactes du trigger (format/flags/état)
**TODO**
- [ ] Déduire conditions runtime :
  - [ ] format exact
  - [ ] headers/flags requis
  - [ ] état (cache, metadata, thumbnail/full)
  - [ ] bornes réalistes (dimensions, tailles)
- [ ] Créer un input minimal valide qui **reach** la fonction

**RESULT**
```
☐ PASS | ☐ FAIL
Conditions : _____________________________
Input minimal (reach) : ☐ OUI | ☐ NON
Artefacts :
- bugs/<VULN_ID>/03_reachability.md (section “Trigger conditions”)
- bugs/<VULN_ID>/inputs/template_valid.bin
```

---

### Étape 13 : Mapping vecteurs d’attaque (réaliste)
**TODO**
- [ ] Lister vecteurs : gallery, scanner, browser, mail, etc.
- [ ] Pour chacun : permissions, interaction utilisateur, contraintes
- [ ] Choisir le meilleur vecteur pour PoC crash

**RESULT**
```
☐ PASS | ☐ FAIL
Vecteurs viables : _______________________
Vecteur choisi : _________________________
0-click possible : ☐ OUI | ☐ NON | ☐ INCONNU
Artefacts :
- bugs/<VULN_ID>/03_reachability.md (section “Entry mapping”)
```

---

## PHASE D — ENVIRONNEMENT (utile mais ne doit pas bloquer le PoC)

### Étape 14 : Profil mitigations
**TODO**
- [ ] Identifier mitigations actives (ASLR, CFI, PAC, MTE, SELinux…)
- [ ] Noter impact sur exploitation (sans bloquer le PoC crash)

**RESULT**
```
☐ PASS | ☐ FAIL
Mitigations : ____________________________
Impact : _________________________________
Artefacts :
- bugs/<VULN_ID>/04_env.md
```

---

### Étape 15 : Spécification format & mapping champs → variables
**TODO**
- [ ] Documenter structure du format (chunks/markers/headers)
- [ ] Mapper champs contrôlables → variables du code
- [ ] Produire un template “safe-to-mutate” + règles de mutation

**RESULT**
```
☐ PASS | ☐ FAIL
Template valide : ☐ OUI | ☐ NON
Mapping : __________________________________
Artefacts :
- bugs/<VULN_ID>/04_env.md (section “Format mapping”)
- bugs/<VULN_ID>/inputs/template_valid.bin
```

---

### Étape 16 : Heap / allocateur (optionnel PoC)
**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Allocateur : _____________________________
Artefacts :
- bugs/<VULN_ID>/04_env.md (section “Heap”)
```

---

### Étape 17 : Gadgets (hors scope PoC crash)
**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Artefacts :
- bugs/<VULN_ID>/04_env.md (section “Gadgets”)
```

---

## PHASE E — PoC CRASH (objectif principal)

### Étape 18 : Craft input malicieux (à partir du template)
**TODO**
- [ ] Injecter triggers sans casser la validité jusqu’au SINK
- [ ] Versionner 3 inputs :
  - A = reach (valide)
  - B = reach + trigger partiel
  - C = crash (cible)

**RESULT**
```
☐ PASS | ☐ FAIL
Inputs :
- A (reach) : ___________________________
- B (trigger) : __________________________
- C (crash) : ____________________________
Artefacts :
- bugs/<VULN_ID>/inputs/template_valid.bin
- bugs/<VULN_ID>/inputs/poc_crash.bin
- bugs/<VULN_ID>/05_poc.md
```

---

### Étape 19 : Test crash (env instrumenté si possible)
**TODO**
- [ ] Exécuter sur env instrumenté (ASAN/MSAN/trace)
- [ ] Capturer report complet + stack trace

**RESULT**
```
☐ PASS | ☐ FAIL
Crash reproduit : ☐ OUI | ☐ NON
Type report : ____________________________
Stack trace : ____________________________
Artefacts :
- bugs/<VULN_ID>/evidence/logs/asan.txt (ou équivalent)
Gate : si NON → retour Étape 12/18 (pas au SINK / template invalide)
```

---

### Étape 20 : Test crash sur device réel
**TODO**
- [ ] Trigger via vecteur réel choisi
- [ ] Capturer tombstone / logcat filtré

**RESULT**
```
☐ PASS | ☐ FAIL
Crash device : ☐ OUI | ☐ NON
Tombstone : ☐ OUI | ☐ NON
Artefacts :
- bugs/<VULN_ID>/evidence/logs/tombstone.txt
- bugs/<VULN_ID>/05_poc.md
```

---

### Étape 20.5 : Fuzzing confirmation (optionnel)
**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Crashes uniques : ______
Artefacts :
- bugs/<VULN_ID>/evidence/logs/fuzz_summary.md
```

---

### Étape 21 : Setup debug (optionnel)
**RESULT**
```
☐ PASS | ☐ FAIL | ☐ SKIP
Debug OK : ☐ OUI | ☐ NON
Artefacts :
- bugs/<VULN_ID>/evidence/logs/debug_setup.md
```

---

### Étape 22 : Crash analysis
**TODO**
- [ ] PC au crash + contexte (regs/stack/heap)
- [ ] Déterminer ce qui est contrôlé / taille corruption

**RESULT**
```
☐ PASS | ☐ FAIL
PC : 0x____________________
Contrôle : _____________________________
Artefacts :
- bugs/<VULN_ID>/05_poc.md (section “Crash analysis”)
```

---

### Étape 23 : Primitive assessment (sans partir en exploit)
**RESULT**
```
☐ PASS | ☐ FAIL
Primitive : _____________________________
Taille : ______  Précision : ______
Répétable : ☐ OUI | ☐ NON
Artefacts :
- bugs/<VULN_ID>/05_poc.md (section “Primitive”)
```

---

## PHASE F — Primitive & stratégie (optionnel)
> Si ton objectif est “PoC crash”, tu peux **SKIP**.

- Étape 24 : Primitive formelle (description)
- Étape 25 : Stratégie (haut niveau)
- Étape 26 : Leak (si nécessaire)
- Étape 26.3 : Bug auxiliaire (si leak impossible)
- Étape 26.5 : Cible de corruption (haut niveau)
- Étape 26.7 : Single vs multi-stage (design)

---

## PHASE G — Exploit dev (optionnel)
> Rester **haut niveau** tant que tu n’as pas un crash stable + primitive claire.

- Étape 27 : Plan mitigations (haut niveau)
- Étape 27.3 : Allocateur (haut niveau)
- Étape 27.5 : Grooming (haut niveau)
- Étape 28 : Hijack (validation)
- Étape 29 : Chaîne (concept)
- Étape 30 : Démonstration contrôlée (objectif “preuve”)
- Étape 30.3/30.5 : Escape (si applicable)

---

## PHASE H — Intégration & test (optionnel)
- Étape 31–35 : End-to-end + failure analysis

## PHASE I — Stabilisation (optionnel)
- Étape 36–39 : fiabilité, portabilité, edge cases

---

## PHASE J — Documentation / Disclosure

### Étape 40 : Write-up technique
**RESULT** doit inclure : preuve statique + preuve reach + preuve crash + conditions exactes.

### Étape 41 : CVE request
**RESULT** : dossier prêt + timeline.

### Étape 42 : Responsible disclosure
**RESULT** : contact + dates + statut.

### Étape 43 : Pack final
**RESULT** : inputs + scripts + README.

---

## Résumé final (gates PoC)
Pour atteindre un **PoC crash**, les gates indispensables sont :
- **Étape 0** (baseline exacte)
- **Étapes 4–10** (validité technique)
- **Étapes 11–13 + 11.5** (atteignabilité prouvée)
- **Étapes 18–20** (input + crash logs)

---

## Quick Reference — patterns PoC-friendly

### Integer issues (priorité)
- `alloc(trunc32(width*height*bpp))` + `copy/write(len64(width...))`
- `size = a*b + c` sans check overflow
- signed/unsigned mix (`sxtw/uxtw`, comparaison signée)
- truncation 64→32 sur taille, mais index reste 64

### Memory issues (priorité)
- memcpy/memmove len dépend input
- boucle index contrôlé sans check strict
- off-by-one sur bornes
- UAF (free puis reuse), refcount/race

### Logic/state/race
- check sur un champ mais usage d’un autre
- TOCTOU (path-based)
- confusion d’état (thumbnail/full, cache, flags)

---

## Annexes

### A1 — Colonnes recommandées pour `triage.csv`
```
vuln_id,target_id,function,addr,sink,source_hyp,type,cwe,C,I,R,K,score,status,notes
```

### A2 — Template de fiche bug (`bugs/<VULN_ID>/00_summary.md`)
```
# <VULN_ID> — <Titre court>

## Target
- TARGET_ID:
- Build-id / Hash:
- Device/OS:

## Résumé
- Type:
- CWE:
- Impact estimé:
- Confiance:

## SINK
- Fonction + addr:
- Instruction(s) clés:

## SOURCE (hyp/confirmé)
- Origine:
- Offset/champ:

## Checks
- Liste des checks + conditions:

## Triggers
- Valeurs:
- Contraintes:

## Reachability
- Entry point:
- Proof-of-reach: (log / hook)

## PoC
- template_valid.bin:
- poc_crash.bin:
- Commandes de repro:
- Logs/tombstone:
```

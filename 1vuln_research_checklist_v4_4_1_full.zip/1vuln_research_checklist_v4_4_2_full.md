# Vulnerability Research Methodology — Checklist v4.4.1 FULL  
**Binary-only · PoC-first · Reality-proof+++ (reviewed & tightened)**

> **Scope** : usage **autorisé** (audit interne, bug bounty, recherche responsable).  
> **Objectif** : passer de l’ASM/microcode/pseudocode à un **PoC démontrable** (A/B/C) malgré : parsing fragile, état caché, ASAN≠prod, contraintes composées, instrumentation perturbatrice, non‑déterminisme, OOM, variations d’environnement.

---

## Ce qui change vs v4.4 FULL (micro-corrections)
- Ajout **0.6 Tooling Snapshot** (versions/outils → repro).
- Ajout **12.5 State Reset Playbook** (cold/warm reproductible).
- Ajout **19.1 Diagnostic Tree** (en plus du rollback rapide).
- Ajout **20.6 Crash/Signal Dedup** (signature stable).
- Ajout **Annexe “Modules par classe de bug”** (UAF/Race/TypeConf adaptent les steps sans dévier vers l’exploit).

> Note : la **Phase ENV** garde les numéros 14/16 pour compatibilité historique, même si elle apparaît après D.

---

## 0) Règles de pilotage

### 0.1 Identifiants & traçabilité (obligatoire)
- **Bug** : `VULN-YYYY-NNN` (ex. `VULN-2026-001`)
- **Binaire** : `TARGET-<name>-<buildid/hash>`
- **Preuve** : référencée (fichier + outil + timestamp)

### 0.2 Artefacts minimum (sinon FAIL)
Pour marquer une étape **PASS**, produire au minimum :
- 1 note `.md` structurée
- 1 preuve “dure” (ASM/pseudo/microcode/screenshot/log/commande+output)
- 1 lien explicite vers `VULN_ID` + `TARGET_ID`

### 0.3 Timeboxing (recommandé)
> Règle : si tu dépasses **2× le budget**, tu **re-scores** / **pivot**.
| Bloc | Budget indicatif |
|------|------------------|
| Baseline (Phase 0) | 30–90 min |
| Static/Triage (Phase A) | 1–4h / fonction |
| Validation (Phase B) | 2–6h / bug |
| Reachability (Phase C) | 1–4h |
| Format/Parsing (Phase D) | 1–4h |
| PoC (Phase E) | 2–10h |
| Patch diff (10.2) | 1–3h |

### 0.4 Gates (stop criteria)
Si un **gate critique** échoue : **rollback** à l’étape indiquée (pas de fuite en avant).

### 0.6 Tooling Snapshot (repro) ✅
**TODO**
- [ ] Lister versions : IDA/Ghidra, scripts, Frida/DBI, adb, firmware build
- [ ] Lister paramètres critiques : options de décompilation, loaders, rebases, symbol maps
- [ ] Fixer un “toolchain ID” (hash/commit de tes scripts si possible)

**RESULT**
```
☐ PASS | ☐ FAIL
Toolchain ID : ___________________________
Artefacts :
- targets/<TARGET_ID>/notes/tooling_snapshot.md
```

---

## 1) Niveaux de PoC (IMPORTANT)

- **PoC-A (Reach)** : preuve que **fonction + sink** sont atteints + valeurs critiques observées.
- **PoC-B (Corruption / Oracle)** : preuve de **corruption/invariant cassé** **ou** divergence “oracle” mesurable (sans crash).
- **PoC-C (Crash)** : crash reproductible (prod-like idéalement) + proof sink + conditions.

---

## 2) Notation standard

- Sinks : `[SINK:OOBW] [SINK:OOBR] [SINK:UAF] [SINK:TYPECONF] [SINK:RACE] [SINK:LOGIC]`
- Sources : `[SRC:FILE:<fmt>:<field/offset>] [SRC:IPC] [SRC:NET] [SRC:STATE]`
- Transforms : `[CAST:U64→U32] [CAST:SXTW] [CAST:UXTW] [MASK:&0x..] [CLAMP] [LOOKUP]`
- Checks : `[CHECK:<cond>]` + `BLOCKING / MAYBE / UNKNOWN`

**Contrôlabilité PARTIEL** : préciser bits/plage contrôlés vs non contrôlés.

---

## 3) Layout repo recommandé

```
/targets/<TARGET_ID>/
  metadata.md
  binaries/
  notes/
    repro_script.md
    env_parity.md
    tooling_snapshot.md

/bugs/<VULN_ID>/
  00_summary.md
  01_static.md
  02_validation.md
  03_reachability.md
  04_format_parsing.md
  04_env.md
  05_poc.md
  evidence/
    asm_snippets.txt
    screenshots/
    logs/
  inputs/
    A_reach.bin
    B_trigger.bin
    C_crash.bin
    *.min.bin
triage.csv
triage_ranked.md
```

---

# PHASE 0 — BASELINE (process-level)

## Étape 0 : Baseline + hash parity (obligatoire)
**TODO**
- [ ] Identifier : process cible, lib, version OS/patch, modèle device
- [ ] Extraire : hash + build-id + dépendances critiques
- [ ] Hash parity : analysé == device
- [ ] Golden run + script repro minimal (push/trigger/logs)

**RESULT**
```
☐ PASS | ☐ FAIL
Hash parity : ☐ OUI | ☐ NON
[GATE] NON → re-extraire / corriger TARGET_ID
```

## Étape 0.5 : Environment parity (cold/warm, flags, configs) ✅
**TODO**
- [ ] Capturer paramètres qui changent le path (flags/config/properties)
- [ ] Définir 2 modes : **Cold** (état initial) / **Warm** (pré‑chauffé)

**RESULT**
```
☐ PASS | ☐ FAIL
Env snapshot : ☐ OUI | ☐ NON
Artefacts : targets/<TARGET_ID>/notes/env_parity.md
```

---

# PHASE A — STATIC + TRIAGE

## Étape 1 : Analyse fonction par fonction
**TODO**
- [ ] Arithmétique + casts
- [ ] Allocations
- [ ] Accès mémoire + index
- [ ] Copies
- [ ] Checks + early exits
- [ ] Marquer sinks

**RESULT**
```
☐ PASS | ☐ FAIL
Fonction : _______________________________
Sinks : _________________________________
Artefacts : bugs/<VULN_ID>/01_static.md
```

## Étape 2 : Fiches “bug potentiel”
**RESULT**
```
☐ PASS | ☐ FAIL
Bugs : ______
Artefacts : triage.csv
```

## Étape 3 : Priorisation PoC-first
Score : `S = C + 2I + 3R - K`, filtre `R==0 => skip`.

## Étape 3.5 : Quick Reach Sanity (5–15 min) ✅
**RESULT**
```
☐ PASS | ☐ FAIL
Touché : ☐ OUI | ☐ NON
Hit-rate : ___/___
Anti-debug suspecté : ☐ OUI | ☐ NON | ☐ INCONNU
```

---

# PHASE B — VALIDATION TECHNIQUE (preuves statiques)

Étapes 4–10.2 identiques à v4.4 FULL :
- 4 ASM vs pseudo
- 5 slicing
- 6 taint
- 7 checks
- 8 contraintes (solver si >3)
- 9 alloc vs access + crash expectation
- 10 verdict
- 10.2 patch diff

---

# PHASE C — ATTEIGNABILITÉ (function-level)

## Étape 11 : Call graph + VM/JIT
## Étape 11.5 : Proof-of-Reach (OBLIGATOIRE) + hit-rate cold/warm ✅

## Étape 12 : Trigger conditions + hidden state

## Étape 12.5 : State Reset Playbook (cold/warm reproductible) ✅
> But : éviter “ça marche 1 fois sur 5” à cause d’état non contrôlé.

**TODO**
- [ ] Définir comment **remettre à zéro** : cache, DB/MediaStore, fichiers temporaires, warmup calls
- [ ] Définir séquence **Cold** et **Warm** (étapes exactes)
- [ ] Valider : même input → même checkpoint (à ± variance mesurée)

**RESULT**
```
☐ PASS | ☐ FAIL
Reset playbook validé : ☐ OUI | ☐ NON
Artefacts : bugs/<VULN_ID>/03_reachability.md (State reset)
```

## Étape 12.6 : Checkpoint Map ✅

## Étape 13 : Entry point mapping

---

# PHASE D — FORMAT & PARSING SURVIVAL

## Étape 15 : Format mapping + endianness/alignment
## Étape 15.5 : Survival window ✅
## Étape 15.6 : Survival search loop ✅
## Étape 15.7 : Input minimization (ddmin) ✅

---

# PHASE ENV — Mitigations / Heap (optionnelle)
> Numéros 14/16 conservés (compatibilité).

## Étape 14 : Mitigations (haut niveau)
## Étape 16 : Heap / allocateur (utile si ASAN≠prod)

---

# PHASE E — PoC (A/B/C)

## Étape 18 : Inputs A/B/C
## Étape 18.5 : Proof-of-SINK + hit-rate ✅
## Étape 18.7 : Proof-of-Corruption (PoC‑B) ✅
## Étape 18.8 : Oracle / Differential Proof (PoC‑B) ✅

## Étape 19 : ASAN vs prod (gate réaliste)
## Étape 19.2 : Non‑determinism control ✅
## Étape 19.3 : Resource monitoring ✅

## Étape 19.1 : Diagnostic Tree (quand “ça ne donne rien”) ✅
> Version explicite (en plus du rollback rapide) : choisir **le bon** rollback.

```
1) Reach = NON ?
   → 0.5 (env parity) + 12 (hidden state) + 12.5 (reset) + 11/13 (entrypoints)

2) Reach = OUI, Sink = NON ?
   → 12.6 (checkpoint map) + 15.6 (survival loop) + 18 (B_trigger) + revoir checks (7)

3) Sink = OUI, valeurs ≠ calculées ?
   → 8 (types/contraintes) + 15 (endianness/alignment) + re-lire transforms (MASK/CLAMP)

4) Sink = OUI, valeurs OK, pas de crash ?
   → viser PoC‑B : 18.7 (corruption) ou 18.8 (oracle)
   → puis 9 (crashability) + 16 (heap) si tu veux PoC‑C

5) Flaky / hit-rate < 80% ?
   → 12.5 (reset) + 19.2 (non-det) + comparer cold vs warm + checkpoint map

6) OOM/HANG/TIMEOUT ?
   → 19.3 + 15.5/15.6 (fenêtre survie) + ajuster “t” (survival loop)
```

## Étape 20 : Crash sur device réel
## Étape 20.5 : Fuzzing confirmation

## Étape 20.6 : Crash/Signal Dedup (signature stable) ✅
**TODO**
- [ ] Dédupliquer : backtrace, PC, module+offset, reason (ASAN class), “last checkpoint”
- [ ] Normaliser une signature : `module!func+off | fault | key args`
- [ ] Ranger les artefacts par signature (1 dossier / signature)

**RESULT**
```
☐ PASS | ☐ FAIL
Nb signatures : ______
Signature principale : ___________________
Artefacts : bugs/<VULN_ID>/evidence/logs/signatures.md
```

---

## Gates de fin
- **PoC-A** : reach PASS + sink PASS (hit-rate)
- **PoC-B** : corruption PASS **ou** oracle PASS
- **PoC-C** : crash prod-like PASS (ou sanitizer crash + PoC-B + justification)

---

## Rollback rapide (résumé)
```
Reach=NON                 → 0.5 + 12 + 12.5 + 11/13
Reach=OUI, Sink=NON        → 12.6 + 15.6 + 18 + 7
Sink=OUI, valeurs ≠ calc   → 8 + 15
Sink=OUI, pas de crash     → 18.7/18.8 + 9/16
Flaky                      → 12.5 + 19.2 + 12.6
OOM/HANG                   → 19.3 + 15.5/15.6
Binaire différent          → 0 + 10.2
```

---

## Annexes — Modules par classe de bug (adaptation rapide)

### M1 — Integer overflow / truncation (alloc vs access)
- Centrer l’effort sur : types exacts, `SXTW/UXTW`, overflow avant check, fenêtre “survivable”.
- Proof : valeurs observées au sink (18.5) vs calcul (8/9).

### M2 — OOB “silencieux” (pas de crash)
- Viser PoC‑B : invariant cassé (18.7) ou oracle (18.8).
- Prioriser : “où écrit/ lit” + proximité objets (16) + signature stable (20.6).

### M3 — UAF
- Compléter l’étape 12 avec une **lifecycle map** :
  - allocations / refcount / ownership / “who frees”
- Checkpoints : “free site”, “reuse site”, “use site”.
- PoC-B : oracle (sortie divergente) ou invariant (use-after-free détectable).

### M4 — Race condition
- Mesurer hit-rate en cold/warm + variance (19.2).
- Réduire instrumentation (side-effects) ; privilégier checkpoints et stats.
- PoC-B possible via oracle (divergence) si crash non déterministe.

### M5 — Type confusion
- Étendre 6/7 avec : type invariants, vtable/dispatch, “assumed type vs real type”.
- PoC-B : divergence oracle (mauvais output/errcode) si crash difficile.

---

## Annexe A6 — Checkpoints typiques par pipeline media

# Annexe — Checkpoints typiques par pipeline media (Android / mobile / vendor codecs)

Cette annexe sert à rendre l’étape **12.6 Checkpoint Map** “plug-and-play” pour les pipelines image/vidéo réels.
L’idée : au lieu d’avoir “ça meurt quelque part”, tu poses des **checkpoints stables** (CPxx) alignés sur les phases
qu’on retrouve presque partout (sniff → parse → alloc → decode → postprocess → output).

---

## A) Convention de checkpoints (CP00…CP99)

### A1 — IDs recommandés
- **CP00** `OPEN` : open/read initial, taille fichier, source (path/uri/FD/mem)
- **CP01** `SNIFF` : détection format (magic, mime, signature)
- **CP02** `DISPATCH` : choix du décodeur (logiciel vs HW, vendor vs AOSP)
- **CP03** `CONTAINER` : demux (si container : HEIF/MP4/WebP RIFF/ISO-BMFF)
- **CP04** `HEADER_PARSE` : parse des headers critiques (dims, bitdepth, chroma)
- **CP05** `META_PARSE` : EXIF/XMP/ICC/MPF, orientation, color profile, thumbnails
- **CP06** `PARAMS_RESOLVE` : options runtime (thumbnail/full, sampleSize, region decode)
- **CP07** `LIMITS_CHECK` : checks globaux (pixel limit, max dim, memory budget)
- **CP08** `TABLES_INIT` : init tables (Huffman, quant, palettes, predictor)
- **CP09** `ALLOC_PLAN` : calcul des tailles (rowbytes/stride/tilebuf/outbuf)
- **CP10** `ALLOC` : allocations effectives (malloc/new/arena/scudo)
- **CP11** `DECODE_SETUP` : init état decode (streams, tiles, frames, threads)
- **CP12** `DECODE_LOOP` : boucle principale (scanlines/tiles/blocks)
- **CP13** `TRANSFORM` : couleurs (ICC/YCbCr→RGB), scaling, rotate, alpha premul
- **CP14** `OUTPUT_WRITE` : écriture vers bitmap/heap buffer/surface
- **CP15** `FINALIZE` : cleanup, free, cache insert, return code
- **CP16** `ERROR_EXIT` : sortie erreur (code + raison + dernier cp atteint)
- **CP17** `CACHE_HIT` : chemin “fast path” (thumbnail existant, cache warm)
- **CP18** `HW_ACCEL` : passage HW decode (media codec / GPU / DSP), si applicable

> Tu n’es pas obligé de tout instrumenter. Souvent, **CP02/04/09/10/12/14** suffisent pour converger vite.

---

## B) Ce qu’on loggue à chaque CP (le “minimum utile”)

### B1 — Champs recommandés (log structuré)
Pour chaque run + checkpoint :

- `run_id`, `variant`, `cold_warm`
- `cp_id`, `cp_name`
- `module`, `func`, `pc` (module+offset), `thread`
- `file_off` (offset stream si dispo), `bytes_remaining`
- `key_vals` (ex : width/height/bpp/stride/tile_w/tile_h/frame_idx)
- `alloc_req`, `alloc_got` (si observable), `ptr` (optionnel)
- `rc` (return/error code), `errno`/`status`
- `t_ms` (timestamp), `dt_ms` (delta depuis CP précédent)
- `rss_kb` / `mem_hint` (si possible)
- `reason` (si error/check/oom)

### B2 — Format “Checkpoint Map” (table)
```
variant | run_id | cold/warm | cp_id | cp_name | module!func+off | reason | key_vals | alloc_req | rc
```

### B3 — “Reason codes” (pour classifier vite)
- `CHECK_FAIL:<name>` (pixel_limit, dim_max, header_sanity, …)
- `OOM:<site>` (alloc outbuf, tilebuf, tables, …)
- `PARSE_FAIL:<stage>` (header/meta/container)
- `DECODE_FAIL:<stage>` (scanline, tile, entropy, …)
- `HW_PATH:<enter/exit>` (hw init fail, fallback)
- `CACHE_PATH:<hit/miss>`
- `TIMEOUT/HANG:<stage>`

---

## C) Checkpoints typiques : images (JPEG/PNG/WebP/GIF/TIFF/DNG/HEIF/AVIF)

### C1 — JPEG (baseline + progressive)
**Chemin typique**
- CP00 OPEN → CP01 SNIFF (FFD8) → CP04 HEADER_PARSE (SOF0/SOF2)  
- CP05 META_PARSE (APP1 EXIF/ICC)  
- CP08 TABLES_INIT (DQT/DHT)  
- CP09 ALLOC_PLAN (rowbytes/MCU/tile) → CP10 ALLOC  
- CP12 DECODE_LOOP (MCU decode)  
- CP13 TRANSFORM (YCbCr→RGB, scaling)  
- CP14 OUTPUT_WRITE (bitmap rows) → CP15 FINALIZE

**Checks “kill-switch” fréquents**
- dims (SOF) sanity, component count, sampling factors
- pixel limit global (w*h <= limit), memory budget
- progressive scans count, restart interval, marker bounds

**Sinks fréquents**
- memcpy/row combine, IDCT buffers, MCU block writes, upsample loops

---

### C2 — PNG
**Chemin typique**
- CP01 SNIFF (89 50 4E 47)  
- CP04 HEADER_PARSE (IHDR) → CP07 LIMITS_CHECK  
- CP08 TABLES_INIT (inflate tables)  
- CP09 ALLOC_PLAN (rowbytes, stride) → CP10 ALLOC  
- CP12 DECODE_LOOP (inflate + unfilter)  
- CP13 TRANSFORM (palette→RGB, gamma/ICC)  
- CP14 OUTPUT_WRITE

**Checks “kill-switch”**
- IHDR constraints (bitdepth/color type), rowbytes overflow, chunk sizes
- zlib stream sanity, interlace mode

**Sinks fréquents**
- row combine/unfilter loops, palette expansion, alpha handling

---

### C3 — WebP (RIFF)
**Chemin typique**
- CP01 SNIFF (RIFF + WEBP) → CP03 CONTAINER (chunks VP8/VP8L/ALPH/ANIM)  
- CP04 HEADER_PARSE (dims) → CP07 LIMITS_CHECK  
- CP09/10 alloc frame buffers  
- CP12 decode blocks/frames  
- CP14 output frame(s)

**Notes**
- Animation : ajouter `frame_idx` dans `key_vals` + CP12 répété par frame

---

### C4 — GIF
**Chemin typique**
- CP01 SNIFF (GIF87a/89a) → CP04 HEADER_PARSE (screen desc)  
- CP08 TABLES_INIT (global/local color tables)  
- CP09/10 alloc canvas + per-frame  
- CP12 decode LZW  
- CP14 blit frame → CP15 finalize

**Points sensibles**
- LZW table growth, frame disposal modes, bounds per frame

---

### C5 — TIFF / DNG
**Chemin typique**
- CP01 SNIFF (II/MM + 42/BigTIFF)  
- CP04 HEADER_PARSE (IFD offsets) → CP05 META_PARSE (tags, strips/tiles)  
- CP07 limits (tile count, strip sizes)  
- CP09 alloc plan (tilebuf/outbuf) → CP10 alloc  
- CP12 decode tiles/strips  
- CP13 transforms (color matrices, ICC, CFA)  
- CP14 output

**Checks “kill-switch”**
- offset/size overflow, tile_count huge, compression mode sanity

---

### C6 — HEIF/AVIF (ISO-BMFF)
**Chemin typique**
- CP03 CONTAINER (ftyp/moov/meta/mdat)  
- CP04 parse item properties (ispe/pixi)  
- CP02 dispatch codec (AV1/HEVC)  
- CP09/10 allocate YUV planes  
- CP12 decode frames/tiles  
- CP13 colorspace conversion  
- CP14 output

**Notes**
- Deux niveaux de parse : container (boxes) + codec (bitstream)
- Ajouter checkpoints internes “codec” si possible : `CP12_CODEC_*`

---

## D) Checkpoints typiques : vidéo (MP4/3GP) — niveau “thumbnail extraction”
(utile si ton pipeline génère une preview ou extrait une frame)

- CP03 CONTAINER (moov/mdat, trak selection)
- CP05 META_PARSE (rotation/orientation, color info)
- CP02 DISPATCH (HW decode vs SW)
- CP10 alloc decode surfaces/buffers
- CP12 decode 1 frame / seek
- CP14 output frame → bitmap/texture
- CP15 finalize/cache

---

## E) Checkpoints “Android reality” (ceux qui te piègent en pratique)

### E1 — MediaStore / MediaScanner / Gallery
- CP17 CACHE_HIT : thumbnail déjà présent → pas de full decode
- CP06 PARAMS_RESOLVE : “need full-res?” dépend de metadata DB
- CP05 META_PARSE : EXIF/ICC/Orientation peut forcer un chemin

**Astuce** : loggue toujours `thumbnail_mode`, `full_decode`, `media_scanner_state`, `cache_hit`.

### E2 — Path “HW decode / fallback”
- CP18 HW_ACCEL : tentative HW → failure → fallback SW (ou inverse)
- Bugs peuvent être seulement SW ou seulement HW

**Astuce** : une variable `decode_backend = {HW,SW,VENDOR,AOSP}` dans tous les logs.

### E3 — Multi-thread / worker pools
- CP12 DECODE_LOOP peut se faire sur un worker
- Loggue `thread_id` + `phase` + “which thread touched sink”.

---

## F) Templates prêts à coller

### F1 — Table de checkpoint map (markdown)
```md
| variant | run | cold/warm | last_cp | reason | reach | sink | key_vals | alloc_req | rc |
|--------|-----|-----------|---------|--------|------|------|----------|-----------|----|
| A_reach | 01 | cold | CP12 | OK | yes | no | w=1024 h=768 bpp=4 | out=3145728 | 0 |
| B_trig  | 02 | cold | CP10 | OOM:outbuf | yes | no | w=65535 h=65535 | out=... | -12 |
```

### F2 — Signature stable (crash/signal dedup)
`sig = module!func+off | fault | last_cp | key_vals_min`

---

## G) Comment l’utiliser dans ta v4.4.1
- **Étape 12.6** : choisis 6–10 CP (souvent CP02/04/09/10/12/13/14/16/17/18)
- **Étape 15.6** : utilise CPxx comme “last_checkpoint” dans la bisection (survival loop)
- **Étape 19.2** : compare hit-rate par CP entre cold vs warm
- **Étape 18.8** : oracle = output_hash/dims/rc par CP14/CP15

---

## H) Mini-checklist “setup rapide” (si tu veux juste converger)
- [ ] Log CP02, CP04, CP09, CP10, CP12, CP14, CP16
- [ ] Ajoute `decode_backend`, `thumbnail_mode`, `cache_hit`, `w/h/bpp/stride`
- [ ] Mesure hit-rate (20 runs) cold/warm
- [ ] Si ça meurt avant sink : survival loop 15.6 + checkpoint map 12.6
- [ ] Si sink=OUI sans crash : PoC-B via oracle 18.8


# Vulnerability Research Methodology — Checklist v4.4 (Binary-only, PoC-first, “Reality-proof+++”)

> **Scope** : usage **autorisé** (audit interne, bug bounty, recherche responsable).  
> **Objectif** : obtenir un **PoC démontrable** (A/B/C) *et* éviter les impasses “réel mais silencieux / non déterministe / OOM / env différent”.

---

## Changements v4.4 (par rapport à v4.3)
- Ajout **Phase 0.5 Environment Parity** (feature flags / configs / propriétés runtime).
- Ajout **15.7 Input Minimization** (ddmin) pour A/B/C.
- Ajout **12.6 Checkpoint Map** (où ça casse exactement + raison).
- Ajout **18.8 Differential/Oracle Proof** (preuve sans crash via divergence observable).
- Ajout **19.2 Non-determinism Control** (cold/warm runs + variance + thresholds).
- Ajout **19.3 Resource Monitoring** (OOM/hang/timeout diagnostics).
- Légère clarification des *gates* (PASS/NEUTRAL/FAIL) pour éviter les faux blocages.

---

## 0) Principes & niveaux de PoC

### PoC levels
- **PoC-A (Reach)** : fonction + sink atteints, valeurs critiques observées.
- **PoC-B (Corruption/Oracle)** : corruption/invariant cassé **ou** divergence oracle (sans crash).
- **PoC-C (Crash)** : crash reproductible (prod-like idéalement) + proof sink.

### Timeboxing
> Si > **2× budget**, re-score/pivot.  
Baseline 30–90 min · Static 1–4h/fonction · Validation 2–6h/bug · Reach 1–4h · PoC 2–10h.

---

## PHASE 0 — BASELINE (process-level)

### Étape 0 : Baseline + hash parity (obligatoire)
**TODO**
- [ ] TARGET_ID, build-id/hash, dépendances
- [ ] Hash parity (analysé == device)
- [ ] Golden run + script repro minimal (push/trigger/logs)

**RESULT**
```
☐ PASS | ☐ FAIL
Hash parity : ☐ OUI | ☐ NON
Gate : si NON → re-extraire / corriger TARGET_ID
```

### Étape 0.5 : Environment Parity (anti “même binaire, comportement différent”) ✅
**TODO**
- [ ] Capturer “paramètres d’environnement” qui changent le path :
  - [ ] properties / flags / config files / build variants
  - [ ] mode thumbnail/full, cache ON/OFF, accélération HW, codecs préférés
  - [ ] options de décodage (subsample, bounds decode, EXIF/ICC paths)
- [ ] Définir 2 modes de test :
  - **Cold** : cache vide / état initial
  - **Warm** : cache préchauffé / mêmes appels précédents

**RESULT**
```
☐ PASS | ☐ FAIL
Env snapshot (cold/warm) documenté : ☐ OUI | ☐ NON
Artefacts : targets/<TARGET_ID>/notes/env_parity.md
```

---

## PHASE A — STATIC + TRIAGE (inchangé v4.3)

- Étape 1 : analyse fonction par fonction (+ tags `[SINK]`, `[CAST]`, `[CHECK]`)
- Étape 2 : fiches bug potentiel (SRC/SINK/entrypoints)
- Étape 3 : scoring PoC-first `S = C + 2I + 3R - K`, filtre `R==0 => skip`
- Étape 3.5 : quick reach sanity + **hit-rate** + note anti-debug/side-effects

---

## PHASE B — VALIDATION TECHNIQUE (inchangé v4.3)

- Étapes 4–10.2 : ASM proof, slicing, taint, checks, contraintes (solver si >3), alloc vs access + crash expectation, verdict, patch diff.

---

## PHASE C — ATTEIGNABILITÉ (function-level)

### Étape 11.5 : Proof-of-Reach + hit-rate (obligatoire)
**Ajouter**
- [ ] Mesurer **hit-rate** sur `N` runs (ex: 20) en **cold** et **warm** (Phase 0.5)

**RESULT**
```
☐ PASS | ☐ FAIL
Hit-rate cold : ___/___
Hit-rate warm : ___/___
Gate : <80% ⇒ traiter comme non-déterminisme/state (voir 19.2)
```

### Étape 12 : Trigger conditions + hidden state (v4.3)
### Étape 12.6 : Checkpoint Map (où ça casse exactement) ✅
> Quand “ça ne crash pas / n’atteint pas le sink”, il faut savoir **où** ça s’arrête.

**TODO**
- [ ] Définir des checkpoints (parsing stage / sous-fonctions / checks clés)
- [ ] Pour chaque run : dernier checkpoint atteint + raison de sortie (check fail / alloc fail / état)
- [ ] Produire un tableau “trop utile” :
  - input variant → last_checkpoint → reason → observed args

**RESULT**
```
☐ PASS | ☐ FAIL
Checkpoint map produite : ☐ OUI | ☐ NON
Artefacts : evidence/logs/checkpoint_map.md
```

---

## PHASE D — FORMAT & PARSING SURVIVAL

### Étape 15.5 : Survival window + Étape 15.6 : Survival search loop (v4.3)

### Étape 15.7 : Input Minimization (ddmin) ✅
> Une fois A/B/C obtenus, **réduire** l’input pour supprimer le bruit.

**TODO**
- [ ] Minimiser A_reach en conservant Reach + args
- [ ] Minimiser B_trigger en conservant Proof-of-SINK
- [ ] Minimiser C_crash (ou PoC-B) en conservant le signal
- [ ] Garder **avant/après** + delta

**RESULT**
```
☐ PASS | ☐ FAIL
Minimisation A/B/C : ☐ OUI | ☐ NON
Artefacts :
- inputs/A_reach.min.bin
- inputs/B_trigger.min.bin
- inputs/C_crash.min.bin (si applicable)
- evidence/logs/minimize.md
```

---

## PHASE E — PoC (A/B/C)

### Étape 18.5 : Proof-of-SINK + hit-rate (v4.3)

### Étape 18.7 : Proof-of-Corruption (PoC-B) (v4.3)

### Étape 18.8 : Differential / Oracle Proof (PoC-B) ✅
> Quand pas de crash et pas d’invariant interne facilement observable, utiliser un **oracle externe** :
> “Même input → sortie attendue stable” vs “sortie divergente”.

**TODO**
- [ ] Définir un oracle mesurable :
  - [ ] hash/CRC du bitmap/output
  - [ ] dimensions/stride invariants
  - [ ] erreurs/return codes attendus
  - [ ] comparaison à un décodeur de référence (si applicable)
- [ ] Mesurer divergence entre A vs B vs C (ou entre runs) de manière reproductible

**RESULT**
```
☐ PASS | ☐ FAIL
Oracle défini : ☐ OUI | ☐ NON
Divergence reproductible : ___/___
PoC-B atteint via oracle : ☐ OUI | ☐ NON
Artefacts : evidence/logs/oracle_proof.md
```

### Étape 19 : ASAN vs prod (v4.3, gate assoupli)

### Étape 19.2 : Non-determinism Control (quand hit-rate < 80%) ✅
**TODO**
- [ ] Séparer runs **cold** et **warm**
- [ ] Répéter `N` fois et mesurer variance (hit-rate, checkpoints, oracle)
- [ ] Si race suspectée : documenter les symptômes (variance, timing sensitivity)
- [ ] Stabiliser *sans* changer le bug (ex: contrôler état/caches, pas “guérir”)

**RESULT**
```
☐ PASS | ☐ FAIL
Variance quantifiée : ☐ OUI | ☐ NON
Cause la plus probable : ☐ state | ☐ race | ☐ heap | ☐ instrumentation | ☐ inconnu
Artefacts : evidence/logs/nondet.md
```

### Étape 19.3 : Resource Monitoring (OOM/hang/timeout) ✅
**TODO**
- [ ] Sur chaque run, collecter :
  - [ ] pic mémoire (ou indicateur), durée, timeouts
  - [ ] codes d’erreur / early exit
- [ ] Catégoriser l’échec :
  - OOM vs check fail vs hang vs “silent continue”

**RESULT**
```
☐ PASS | ☐ FAIL
Catégorie d’échec identifiée : ☐ OOM | ☐ CHECK | ☐ HANG | ☐ SILENT | ☐ OTHER
Artefacts : evidence/logs/resources.md
```

---

## Gates PoC (v4.4)

- **PoC-A atteint** si : Proof-of-Reach PASS + Proof-of-SINK PASS (hit-rate mesuré)
- **PoC-B atteint** si : Proof-of-Corruption PASS **OU** Oracle Proof PASS
- **PoC-C atteint** si : crash prod-like PASS (ou crash sanitizer + explication + PoC-B)

---

## Annexes

### Template “Checkpoint Map” (12.6)
```
variant | run_id | cold/warm | last_checkpoint | reason | reach? | sink? | len/index observed | notes
```

### Template “Oracle Proof” (18.8)
```
input | run_id | output_hash | dims/stride | return_code | divergence? | notes
```

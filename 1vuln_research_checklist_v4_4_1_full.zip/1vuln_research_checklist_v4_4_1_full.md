# Vulnerability Research Methodology — Checklist v4.4.1 FULL  
**Binary-only · PoC-first · Reality-proof+++ (reviewed & tightened)**

> **Scope** : usage **autorisé** (audit interne, bug bounty, recherche responsable).  
> **Objectif** : passer de l’ASM/microcode/pseudocode à un **PoC démontrable** (A/B/C) malgré : parsing fragile, état caché, ASAN≠prod, contraintes composées, instrumentation perturbatrice, non‑déterminisme, OOM, variations d’environnement.

---

## Ce qui change vs v4.4 FULL (micro-corrections)
- Ajout **0.6 Tooling Snapshot** (versions/outils → repro).
- Ajout **12.5 State Reset Playbook** (cold/warm reproductible).
- Ajout **19.1 Diagnostic Tree** (en plus du rollback rapide).
- Ajout **20.6 Crash/Signal Dedup** (signature stable).
- Ajout **Annexe “Modules par classe de bug”** (UAF/Race/TypeConf adaptent les steps sans dévier vers l’exploit).

> Note : la **Phase ENV** garde les numéros 14/16 pour compatibilité historique, même si elle apparaît après D.

---

## 0) Règles de pilotage

### 0.1 Identifiants & traçabilité (obligatoire)
- **Bug** : `VULN-YYYY-NNN` (ex. `VULN-2026-001`)
- **Binaire** : `TARGET-<name>-<buildid/hash>`
- **Preuve** : référencée (fichier + outil + timestamp)

### 0.2 Artefacts minimum (sinon FAIL)
Pour marquer une étape **PASS**, produire au minimum :
- 1 note `.md` structurée
- 1 preuve “dure” (ASM/pseudo/microcode/screenshot/log/commande+output)
- 1 lien explicite vers `VULN_ID` + `TARGET_ID`

### 0.3 Timeboxing (recommandé)
> Règle : si tu dépasses **2× le budget**, tu **re-scores** / **pivot**.
| Bloc | Budget indicatif |
|------|------------------|
| Baseline (Phase 0) | 30–90 min |
| Static/Triage (Phase A) | 1–4h / fonction |
| Validation (Phase B) | 2–6h / bug |
| Reachability (Phase C) | 1–4h |
| Format/Parsing (Phase D) | 1–4h |
| PoC (Phase E) | 2–10h |
| Patch diff (10.2) | 1–3h |

### 0.4 Gates (stop criteria)
Si un **gate critique** échoue : **rollback** à l’étape indiquée (pas de fuite en avant).

### 0.6 Tooling Snapshot (repro) ✅
**TODO**
- [ ] Lister versions : IDA/Ghidra, scripts, Frida/DBI, adb, firmware build
- [ ] Lister paramètres critiques : options de décompilation, loaders, rebases, symbol maps
- [ ] Fixer un “toolchain ID” (hash/commit de tes scripts si possible)

**RESULT**
```
☐ PASS | ☐ FAIL
Toolchain ID : ___________________________
Artefacts :
- targets/<TARGET_ID>/notes/tooling_snapshot.md
```

---

## 1) Niveaux de PoC (IMPORTANT)

- **PoC-A (Reach)** : preuve que **fonction + sink** sont atteints + valeurs critiques observées.
- **PoC-B (Corruption / Oracle)** : preuve de **corruption/invariant cassé** **ou** divergence “oracle” mesurable (sans crash).
- **PoC-C (Crash)** : crash reproductible (prod-like idéalement) + proof sink + conditions.

---

## 2) Notation standard

- Sinks : `[SINK:OOBW] [SINK:OOBR] [SINK:UAF] [SINK:TYPECONF] [SINK:RACE] [SINK:LOGIC]`
- Sources : `[SRC:FILE:<fmt>:<field/offset>] [SRC:IPC] [SRC:NET] [SRC:STATE]`
- Transforms : `[CAST:U64→U32] [CAST:SXTW] [CAST:UXTW] [MASK:&0x..] [CLAMP] [LOOKUP]`
- Checks : `[CHECK:<cond>]` + `BLOCKING / MAYBE / UNKNOWN`

**Contrôlabilité PARTIEL** : préciser bits/plage contrôlés vs non contrôlés.

---

## 3) Layout repo recommandé

```
/targets/<TARGET_ID>/
  metadata.md
  binaries/
  notes/
    repro_script.md
    env_parity.md
    tooling_snapshot.md

/bugs/<VULN_ID>/
  00_summary.md
  01_static.md
  02_validation.md
  03_reachability.md
  04_format_parsing.md
  04_env.md
  05_poc.md
  evidence/
    asm_snippets.txt
    screenshots/
    logs/
  inputs/
    A_reach.bin
    B_trigger.bin
    C_crash.bin
    *.min.bin
triage.csv
triage_ranked.md
```

---

# PHASE 0 — BASELINE (process-level)

## Étape 0 : Baseline + hash parity (obligatoire)
**TODO**
- [ ] Identifier : process cible, lib, version OS/patch, modèle device
- [ ] Extraire : hash + build-id + dépendances critiques
- [ ] Hash parity : analysé == device
- [ ] Golden run + script repro minimal (push/trigger/logs)

**RESULT**
```
☐ PASS | ☐ FAIL
Hash parity : ☐ OUI | ☐ NON
[GATE] NON → re-extraire / corriger TARGET_ID
```

## Étape 0.5 : Environment parity (cold/warm, flags, configs) ✅
**TODO**
- [ ] Capturer paramètres qui changent le path (flags/config/properties)
- [ ] Définir 2 modes : **Cold** (état initial) / **Warm** (pré‑chauffé)

**RESULT**
```
☐ PASS | ☐ FAIL
Env snapshot : ☐ OUI | ☐ NON
Artefacts : targets/<TARGET_ID>/notes/env_parity.md
```

---

# PHASE A — STATIC + TRIAGE

## Étape 1 : Analyse fonction par fonction
**TODO**
- [ ] Arithmétique + casts
- [ ] Allocations
- [ ] Accès mémoire + index
- [ ] Copies
- [ ] Checks + early exits
- [ ] Marquer sinks

**RESULT**
```
☐ PASS | ☐ FAIL
Fonction : _______________________________
Sinks : _________________________________
Artefacts : bugs/<VULN_ID>/01_static.md
```

## Étape 2 : Fiches “bug potentiel”
**RESULT**
```
☐ PASS | ☐ FAIL
Bugs : ______
Artefacts : triage.csv
```

## Étape 3 : Priorisation PoC-first
Score : `S = C + 2I + 3R - K`, filtre `R==0 => skip`.

## Étape 3.5 : Quick Reach Sanity (5–15 min) ✅
**RESULT**
```
☐ PASS | ☐ FAIL
Touché : ☐ OUI | ☐ NON
Hit-rate : ___/___
Anti-debug suspecté : ☐ OUI | ☐ NON | ☐ INCONNU
```

---

# PHASE B — VALIDATION TECHNIQUE (preuves statiques)

Étapes 4–10.2 identiques à v4.4 FULL :
- 4 ASM vs pseudo
- 5 slicing
- 6 taint
- 7 checks
- 8 contraintes (solver si >3)
- 9 alloc vs access + crash expectation
- 10 verdict
- 10.2 patch diff

---

# PHASE C — ATTEIGNABILITÉ (function-level)

## Étape 11 : Call graph + VM/JIT
## Étape 11.5 : Proof-of-Reach (OBLIGATOIRE) + hit-rate cold/warm ✅

## Étape 12 : Trigger conditions + hidden state

## Étape 12.5 : State Reset Playbook (cold/warm reproductible) ✅
> But : éviter “ça marche 1 fois sur 5” à cause d’état non contrôlé.

**TODO**
- [ ] Définir comment **remettre à zéro** : cache, DB/MediaStore, fichiers temporaires, warmup calls
- [ ] Définir séquence **Cold** et **Warm** (étapes exactes)
- [ ] Valider : même input → même checkpoint (à ± variance mesurée)

**RESULT**
```
☐ PASS | ☐ FAIL
Reset playbook validé : ☐ OUI | ☐ NON
Artefacts : bugs/<VULN_ID>/03_reachability.md (State reset)
```

## Étape 12.6 : Checkpoint Map ✅

## Étape 13 : Entry point mapping

---

# PHASE D — FORMAT & PARSING SURVIVAL

## Étape 15 : Format mapping + endianness/alignment
## Étape 15.5 : Survival window ✅
## Étape 15.6 : Survival search loop ✅
## Étape 15.7 : Input minimization (ddmin) ✅

---

# PHASE ENV — Mitigations / Heap (optionnelle)
> Numéros 14/16 conservés (compatibilité).

## Étape 14 : Mitigations (haut niveau)
## Étape 16 : Heap / allocateur (utile si ASAN≠prod)

---

# PHASE E — PoC (A/B/C)

## Étape 18 : Inputs A/B/C
## Étape 18.5 : Proof-of-SINK + hit-rate ✅
## Étape 18.7 : Proof-of-Corruption (PoC‑B) ✅
## Étape 18.8 : Oracle / Differential Proof (PoC‑B) ✅

## Étape 19 : ASAN vs prod (gate réaliste)
## Étape 19.2 : Non‑determinism control ✅
## Étape 19.3 : Resource monitoring ✅

## Étape 19.1 : Diagnostic Tree (quand “ça ne donne rien”) ✅
> Version explicite (en plus du rollback rapide) : choisir **le bon** rollback.

```
1) Reach = NON ?
   → 0.5 (env parity) + 12 (hidden state) + 12.5 (reset) + 11/13 (entrypoints)

2) Reach = OUI, Sink = NON ?
   → 12.6 (checkpoint map) + 15.6 (survival loop) + 18 (B_trigger) + revoir checks (7)

3) Sink = OUI, valeurs ≠ calculées ?
   → 8 (types/contraintes) + 15 (endianness/alignment) + re-lire transforms (MASK/CLAMP)

4) Sink = OUI, valeurs OK, pas de crash ?
   → viser PoC‑B : 18.7 (corruption) ou 18.8 (oracle)
   → puis 9 (crashability) + 16 (heap) si tu veux PoC‑C

5) Flaky / hit-rate < 80% ?
   → 12.5 (reset) + 19.2 (non-det) + comparer cold vs warm + checkpoint map

6) OOM/HANG/TIMEOUT ?
   → 19.3 + 15.5/15.6 (fenêtre survie) + ajuster “t” (survival loop)
```

## Étape 20 : Crash sur device réel
## Étape 20.5 : Fuzzing confirmation

## Étape 20.6 : Crash/Signal Dedup (signature stable) ✅
**TODO**
- [ ] Dédupliquer : backtrace, PC, module+offset, reason (ASAN class), “last checkpoint”
- [ ] Normaliser une signature : `module!func+off | fault | key args`
- [ ] Ranger les artefacts par signature (1 dossier / signature)

**RESULT**
```
☐ PASS | ☐ FAIL
Nb signatures : ______
Signature principale : ___________________
Artefacts : bugs/<VULN_ID>/evidence/logs/signatures.md
```

---

## Gates de fin
- **PoC-A** : reach PASS + sink PASS (hit-rate)
- **PoC-B** : corruption PASS **ou** oracle PASS
- **PoC-C** : crash prod-like PASS (ou sanitizer crash + PoC-B + justification)

---

## Rollback rapide (résumé)
```
Reach=NON                 → 0.5 + 12 + 12.5 + 11/13
Reach=OUI, Sink=NON        → 12.6 + 15.6 + 18 + 7
Sink=OUI, valeurs ≠ calc   → 8 + 15
Sink=OUI, pas de crash     → 18.7/18.8 + 9/16
Flaky                      → 12.5 + 19.2 + 12.6
OOM/HANG                   → 19.3 + 15.5/15.6
Binaire différent          → 0 + 10.2
```

---

## Annexes — Modules par classe de bug (adaptation rapide)

### M1 — Integer overflow / truncation (alloc vs access)
- Centrer l’effort sur : types exacts, `SXTW/UXTW`, overflow avant check, fenêtre “survivable”.
- Proof : valeurs observées au sink (18.5) vs calcul (8/9).

### M2 — OOB “silencieux” (pas de crash)
- Viser PoC‑B : invariant cassé (18.7) ou oracle (18.8).
- Prioriser : “où écrit/ lit” + proximité objets (16) + signature stable (20.6).

### M3 — UAF
- Compléter l’étape 12 avec une **lifecycle map** :
  - allocations / refcount / ownership / “who frees”
- Checkpoints : “free site”, “reuse site”, “use site”.
- PoC-B : oracle (sortie divergente) ou invariant (use-after-free détectable).

### M4 — Race condition
- Mesurer hit-rate en cold/warm + variance (19.2).
- Réduire instrumentation (side-effects) ; privilégier checkpoints et stats.
- PoC-B possible via oracle (divergence) si crash non déterministe.

### M5 — Type confusion
- Étendre 6/7 avec : type invariants, vtable/dispatch, “assumed type vs real type”.
- PoC-B : divergence oracle (mauvais output/errcode) si crash difficile.

